package com.mvc.util;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DBConnection
 */
@WebServlet("/DBConnection")
public class DBConnection extends HttpServlet {
	
	public static Connection createConnection() throws SQLException, ClassNotFoundException{
		
		Connection con = null;
		Class.forName("org.postgresql.Driver");
		String dbconn = "jdbc:postgresql://ec2-54-243-211-197.compute-1.amazonaws.com:5432/daqgfuse35tu60?user=detgygtbhnchqu&password=8914f35626da6a1a7c1a7ba82525b2cfda2655acb3f3ac14528d8d0ec0bf8e7d&ssl=true&sslfactory=org.postgresql.ssl.NonValidatingFactory";
		String username = "detgygtbhnchqu";// dbUri.getUserInfo().split(":")[0];
		String password = "8914f35626da6a1a7c1a7ba82525b2cfda2655acb3f3ac14528d8d0ec0bf8e7d";//dbUri.getUserInfo().split(":")[1];
		
		try{
			con = DriverManager.getConnection(dbconn, username, password);
			System.out.println("Printing connection object "+con);
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return con;
	}

}
