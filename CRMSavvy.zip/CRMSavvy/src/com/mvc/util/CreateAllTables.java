package com.mvc.util;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

public class CreateAllTables {
 public void createUserTable() throws ClassNotFoundException, SQLException{
	DBConnection connections = new DBConnection();

		Connection connection = connections.createConnection();

		Statement stmt = null;
		try {
			stmt = connection.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//TRUNCATE parentStock
		//stmt.executeQuery("DELETE from users where user_name='"+"verma9931@gmail.com"+"'");
		
		//	stmt.executeQuery("ALTER TABLE CommentDTO ADD COLUMN contactnum_email VARCHAR");
		stmt.executeQuery("TRUNCATE leads");
		//stmt.executeUpdate("DROP TABLE IF EXISTS user_contact");
		//stmt.executeUpdate("CREATE TABLE users(id SERIAL PRIMARY KEY,name varchar(255),role varchar(25),user_name varchar(25),password varchar(25),e_mail varchar(255),totalLead int,openLead int,closeLead int)");
		// stmt.executeUpdate("INSERT INTO users(user_name,password,name,role,e_mail,totalLead,openLead,closeLead) VALUES ('verma9931@gmail.com','abhi007','Abhishek Verma','Admin','verma9931@gmail.com',100,80,20)");
		// stmt.executeUpdate("INSERT INTO users(user_name,password,name,role,e_mail,totalLead,openLead,closeLead) VALUES ('va00017@gmail.com','abhi007','Himanshu Mehta','EMP','va00017@gmail.com',150,100,50)");
		// stmt.executeUpdate("CREATE TABLE leads(id SERIAL PRIMARY KEY,leadId varchar(255),SUB_LEAD_NO varchar(25),Responsible_Person varchar(25),NAME_OF_SHAREHOLDER varchar(25),FATHER_HUSBAND_NAME varchar(25),ADDRES varchar(255),CITY varchar(25),COUNTRY varchar(25),PINCODE varchar(25),NAME_OF_COMPANY varchar(100),NO_OF_SHARES varchar(25),FOLIO_NUMBER_OF_SECURITIES varchar(100),IEPF varchar(25),CMP varchar(25),VALUATION varchar(25),CUMULATIVE_VALUATION varchar(25),COMMENTS_BY_RTA varchar(300),STATUS varchar(100),LAST_CONTACTED_ON varchar(25),COMMENTS_BY_CALLER varchar(300),NEXT_ACTION_DATE varchar(25),REMARKS_BY_FINDER varchar(25),CONTACT_FOUND varchar(25),PARENT_LEAD_ID varchar(25))");		
		// stmt.executeUpdate("CREATE TABLE parentStock(symbol varchar(18),close decimal(8,2))");
		// stmt.executeUpdate("CREATE TABLE userStock( lead_id VARCHAR REFERENCES leads,parentStock varchar(18),count int,mention_if_in_IEPF varchar(18),no_of_stocks int,CMP decimal(8,2),Valuation decimal(8,2))");
		// stmt.executeUpdate("CREATE TABLE user_contact(FOREIGN KEY (lead_id) REFERENCES leads (ID),id SERIAL PRIMARY KEY,CONTACT_PERSON varchar(100),CONTACT_NO varchar(25),CONTACT_SOURCE varchar(25),ADDRESS varchar(300),ADDRESS_SOURCE varchar(100),EMAIL_ID varchar(50),PARENT_LEAD_ID varchar(25))");
		 //stmt.executeUpdate("ALTER TABLE users ADD PRIMARY KEY (user_name)");

		/*
		 * CREATE TABLE table_name (column_name1 datatype, column_name2
		 * datatype, ... column_nameN datatype );
		 */
		// stmt.executeUpdate("INSERT INTO users(email,password) VALUES
		// ('verma9931@gmail.com','abhi007')");
		 System.out.println("table created");
		 stmt.close();
		 connection.close();
	
 }
 public void tableName() throws ClassNotFoundException, SQLException{
	 DBConnection connections = new DBConnection();

		Connection connection = connections.createConnection();

		Statement stmt = null;
		try {
			stmt = connection.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

     try {

    	 stmt = connection.createStatement();

         String sql = "select * from CommentDTO";
        ResultSet rs = stmt.executeQuery(sql);
         ResultSetMetaData metaData = rs.getMetaData();

         int rowCount = metaData.getColumnCount();

         System.out.println("Table Name : " + metaData.getTableName(2));
         System.out.println("Field  \tDataType");

         for (int i = 0; i < rowCount; i++) {
             System.out.println(i+1+" "+metaData.getColumnName(i + 1) + "  \t");
            // System.out.println(metaData.getColumnTypeName(i + 1));
         }
     } catch (Exception e) {
         System.out.println(e);
     }
     connection.close();
 	
 }
 public static void main(String[] args) throws ClassNotFoundException, SQLException {
	 CreateAllTables allTables = new CreateAllTables();
	allTables.createUserTable();
	////stmt.executeQuery("DELETE from users where user_name='"+"verma9931@gmail.com"+"'");
	// allTables.tableName();
}
}
