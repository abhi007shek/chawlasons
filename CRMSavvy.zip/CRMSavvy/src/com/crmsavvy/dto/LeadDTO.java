package com.crmsavvy.dto;

import java.util.Set;

import javax.annotation.Generated;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "leads")
public class LeadDTO {
	public int subLead;
	public int getSubLead() {
		return subLead;
	}

	public void setSubLead(int subLead) {
		this.subLead = subLead;
	}

	public int getLeadId() {
		return leadId;
	}

	public void setLeadId(int leadId) {
		this.leadId = leadId;
	}

	@Id
	@Column(name = "id")
	@GeneratedValue(generator = "system-uuid")
	@GenericGenerator(name = "system-uuid", strategy = "uuid")
	public String getId() {
		return Id;
	}

	public void setId(String id) {
		Id = id;
	}

	public String getResponsible_Person() {
		return Responsible_Person;
	}

	public void setResponsible_Person(String responsible_Person) {
		Responsible_Person = responsible_Person;
	}

	public String getFirst_Name() {
		return First_Name;
	}

	public void setFirst_Name(String first_Name) {
		First_Name = first_Name;
	}

	public String getFather_hus_name() {
		return father_hus_name;
	}

	public void setFather_hus_name(String father_hus_name) {
		this.father_hus_name = father_hus_name;
	}

	public String getLast_Name() {
		return Last_Name;
	}

	public void setLast_Name(String last_Name) {
		Last_Name = last_Name;
	}

	public String getStatus() {
		return Status;
	}

	public void setStatus(String status) {
		Status = status;
	}

	public String getComments_by_RTA_if_any() {
		return Comments_by_RTA_if_any;
	}

	public void setComments_by_RTA_if_any(String comments_by_RTA_if_any) {
		Comments_by_RTA_if_any = comments_by_RTA_if_any;
	}

	public String getComments_by_person_responsible_for_contacting() {
		return Comments_by_person_responsible_for_contacting;
	}

	public void setComments_by_person_responsible_for_contacting(String comments_by_person_responsible_for_contacting) {
		Comments_by_person_responsible_for_contacting = comments_by_person_responsible_for_contacting;
	}

	public String getContact_Found() {
		return Contact_Found;
	}

	public void setContact_Found(String contact_Found) {
		Contact_Found = contact_Found;
	}

	public String getAddress_Source_if_any() {
		return Address_Source_if_any;
	}

	public void setAddress_Source_if_any(String address_Source_if_any) {
		Address_Source_if_any = address_Source_if_any;
	}

	public String getSource_for_contact_no() {
		return Source_for_contact_no;
	}

	public void setSource_for_contact_no(String source_for_contact_no) {
		Source_for_contact_no = source_for_contact_no;
	}

	public String getComments_by_finder_if_any() {
		return Comments_by_finder_if_any;
	}

	public void setComments_by_finder_if_any(String comments_by_finder_if_any) {
		Comments_by_finder_if_any = comments_by_finder_if_any;
	}

	public String getLast_contacted_on() {
		return Last_contacted_on;
	}

	public void setLast_contacted_on(String last_contacted_on) {
		Last_contacted_on = last_contacted_on;
	}

	public String getNext_action_date() {
		return Next_action_date;
	}

	public void setNext_action_date(String next_action_date) {
		Next_action_date = next_action_date;
	}

	public String getAddress() {
		return Address;
	}

	public void setAddress(String address) {
		Address = address;
	}

	public String getState() {
		return State;
	}

	public void setState(String state) {
		State = state;
	}

	public String getCity() {
		return City;
	}

	public void setCity(String city) {
		City = city;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public int getNo_of_share() {
		return no_of_share;
	}

	public void setNo_of_share(int no_of_share) {
		this.no_of_share = no_of_share;
	}

	public String getFOLIO_NUMBER() {
		return FOLIO_NUMBER;
	}

	public void setFOLIO_NUMBER(String fOLIO_NUMBER) {
		FOLIO_NUMBER = fOLIO_NUMBER;
	}

	public String getIEPF() {
		return IEPF;
	}

	public void setIEPF(String iEPF) {
		IEPF = iEPF;
	}

	public String getCMP() {
		return CMP;
	}

	public void setCMP(String cMP) {
		CMP = cMP;
	}

	public String getPIN_Code() {
		return PIN_Code;
	}

	public void setPIN_Code(String pIN_Code) {
		PIN_Code = pIN_Code;
	}

	public String getParentLead() {
		return parentLead;
	}

	public void setParentLead(String parentLead) {
		this.parentLead = parentLead;
	}

	public String getName_of_compny() {
		return name_of_compny;
	}

	public void setName_of_compny(String name_of_compny) {
		this.name_of_compny = name_of_compny;
	}

	@OneToMany(mappedBy = "dto", cascade = CascadeType.ALL)
	public Set<CommentDTO> getCommentList() {
		return commentList;
	}

	public void setCommentList(Set<CommentDTO> commentList) {
		this.commentList = commentList;
	}

	public Set<CommentDTO> commentList;

	@OneToMany(mappedBy = "dto", cascade = CascadeType.ALL)
	public Set<UserStockDTO> getStocks() {
		return stocks;
	}

	public void setStocks(Set<UserStockDTO> stocks) {
		this.stocks = stocks;
	}

	@OneToMany(mappedBy = "dto", cascade = CascadeType.ALL)
	public Set<UserContPersonDTO> getContPersons() {
		return contPersons;
	}

	public void setContPersons(Set<UserContPersonDTO> contPersons) {
		this.contPersons = contPersons;
	}

	public String getCumulative_Valuation() {
		return Cumulative_Valuation;
	}

	public void setCumulative_Valuation(String cumulative_Valuation) {
		Cumulative_Valuation = cumulative_Valuation;
	}

	public float getValuation() {
		return Valuation;
	}

	public void setValuation(float valuation) {
		Valuation = valuation;
	}

	@Column(name = "leadId", columnDefinition = "serial")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int leadId;
	private String Id;
	@Column(name = "Responsible_Person")
	private String Responsible_Person;
	@Column(name = "NAME_OF_SHAREHOLDER")
	private String First_Name;
	@Column(name = "FATHER_HUSBAND_NAME")
	private String father_hus_name;
	private String Last_Name;
	@Column(name = "STATUS")
	private String Status;
	@Column(name = "COMMENTS_BY_RTA")
	private String Comments_by_RTA_if_any;
	@Column(name = "COMMENTS_BY_CALLER")
	private String Comments_by_person_responsible_for_contacting;
	@Column(name = "CONTACT_FOUND")
	private String Contact_Found;
	private String Address_Source_if_any;
	private String Source_for_contact_no;
	@Column(name = "REMARKS_BY_FINDER")
	private String Comments_by_finder_if_any;
	@Column(name = "LAST_CONTACTED_ON")
	private String Last_contacted_on;
	@Column(name = "NEXT_ACTION_DATE")
	private String Next_action_date;
	@Column(name = "ADDRES")
	private String Address;
	private String State;
	@Column(name = "CITY")
	private String City;
	@Column(name = "COUNTRY")
	private String country;
	@Column(name = "NO_OF_SHARES")
	private int no_of_share;
	@Column(name = "FOLIO_NUMBER_OF_SECURITIES")
	private String FOLIO_NUMBER; //NOT IN USE
	@Column(name = "IEPF")
	private String IEPF;
	@Column(name = "CMP")
	private String CMP;
	@Column(name = "PINCODE")
	private String PIN_Code;
	private String parentLead;
	@Column(name = "NAME_OF_COMPANY")
	private String name_of_compny;

	// private Set<LeadDTO> RelatedLeadIds;
	private Set<UserStockDTO> stocks;
	private Set<UserContPersonDTO> contPersons;
	@Column(name = "Responsible_Person")
	private String Cumulative_Valuation;
	private float Valuation;//NOT IN USE
    public String getAssginTo() {
		return AssginTo;
	}

	public void setAssginTo(String assginTo) {
		AssginTo = assginTo;
	}

	public String getAssignBy() {
		return AssignBy;
	}

	public void setAssignBy(String assignBy) {
		AssignBy = assignBy;
	}

	private String AssginTo;
    private String AssignBy;
    public String Type;
    public String getXsecond_joint_holder() {
		return xsecond_joint_holder;
	}

	public void setXsecond_joint_holder(String xsecond_joint_holder) {
		this.xsecond_joint_holder = xsecond_joint_holder;
	}

	public String xsecond_joint_holder;
    


	public String getType() {
		return Type;
	}

	public void setType(String type) {
		Type = type;
	}

	public String getJointHolder() {
		return jointHolder;
	}

	public void setJointHolder(String jointHolder) {
		this.jointHolder = jointHolder;
	}

	public String getAllotmentDate() {
		return allotmentDate;
	}

	public void setAllotmentDate(String allotmentDate) {
		this.allotmentDate = allotmentDate;
	}

	public String jointHolder;
    public String allotmentDate;
	public LeadDTO() {
	}

	public LeadDTO(int leadId, String id, String responsible_Person, String first_Name, String father_hus_name,
			String last_Name, String status, String comments_by_RTA_if_any,
			String comments_by_person_responsible_for_contacting, String contact_Found, String address_Source_if_any,
			String source_for_contact_no, String comments_by_finder_if_any, String last_contacted_on,
			String next_action_date, String address, String state, String city, String country, int no_of_share,
			String fOLIO_NUMBER, String iEPF, String cMP, String pIN_Code, String parentLead, String name_of_compny,
			Set<LeadDTO> relatedLeadIds, Set<UserStockDTO> stocks, Set<UserContPersonDTO> contPersons,
			String cumulative_Valuation, float valuation) {

		this.leadId = leadId;
		Id = id;
		Responsible_Person = responsible_Person;
		First_Name = first_Name;
		this.father_hus_name = father_hus_name;
		Last_Name = last_Name;
		Status = status;
		Comments_by_RTA_if_any = comments_by_RTA_if_any;
		Comments_by_person_responsible_for_contacting = comments_by_person_responsible_for_contacting;
		Contact_Found = contact_Found;
		Address_Source_if_any = address_Source_if_any;
		Source_for_contact_no = source_for_contact_no;
		Comments_by_finder_if_any = comments_by_finder_if_any;
		Last_contacted_on = last_contacted_on;
		Next_action_date = next_action_date;
		Address = address;
		State = state;
		City = city;
		this.country = country;
		this.no_of_share = no_of_share;
		FOLIO_NUMBER = fOLIO_NUMBER;
		IEPF = iEPF;
		CMP = cMP;
		PIN_Code = pIN_Code;
		this.parentLead = parentLead;
		this.name_of_compny = name_of_compny;
		// RelatedLeadIds = relatedLeadIds;
		this.stocks = stocks;
		this.contPersons = contPersons;
		Cumulative_Valuation = cumulative_Valuation;
		Valuation = valuation;
	}

}
