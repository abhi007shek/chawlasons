package com.crmsavvy.dto;

public class FileUploadReqDTO {
	public String TIN;
	public final String getTIN() {
		return TIN;
	}
	public final void setTIN(String tIN) {
		TIN = tIN;
	}
	public final String getReq() {
		return req;
	}
	public final void setReq(String req) {
		this.req = req;
	}
	public String req;
	
}
