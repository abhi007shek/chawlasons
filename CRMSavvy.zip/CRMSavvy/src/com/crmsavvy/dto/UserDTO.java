package com.crmsavvy.dto;

public class UserDTO {
	public String id;
	public String name;
	public String role;
	public String user_name;
	public String e_mail;
	public Integer totalLead;
	public Integer openLead;
	public Integer closeLead;
	public String password;
	public Boolean getIsactive() {
		return isactive;
	}

	public void setIsactive(Boolean isactive) {
		this.isactive = isactive;
	}

	public String getStocktype() {
		return stocktype;
	}

	public void setStocktype(String stocktype) {
		this.stocktype = stocktype;
	}

	public Boolean isactive;
	public String stocktype;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getUser_name() {
		return user_name;
	}

	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}

	public String getE_mail() {
		return e_mail;
	}

	public void setE_mail(String e_mail) {
		this.e_mail = e_mail;
	}

	public Integer getTotalLead() {
		return totalLead;
	}

	public void setTotalLead(Integer totalLead) {
		this.totalLead = totalLead;
	}

	public Integer getOpenLead() {
		return openLead;
	}

	public void setOpenLead(Integer openLead) {
		this.openLead = openLead;
	}

	public Integer getCloseLead() {
		return closeLead;
	}

	public void setCloseLead(Integer closeLead) {
		this.closeLead = closeLead;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}
