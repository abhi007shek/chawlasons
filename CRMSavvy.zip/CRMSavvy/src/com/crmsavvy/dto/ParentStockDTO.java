package com.crmsavvy.dto;

public class ParentStockDTO {
	public String getSymbol() {
		return symbol;
	}

	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}

	public float getClose() {
		return close;
	}

	public void setClose(float close) {
		this.close = close;
	}

	public String symbol;
	public float close;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String status;
	public String gettAdressAsperCompany() {
		return tAdressAsperCompany;
	}

	public void settAdressAsperCompany(String tAdressAsperCompany) {
		this.tAdressAsperCompany = tAdressAsperCompany;
	}

	public String tAdressAsperCompany;

}
