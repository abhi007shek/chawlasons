package com.crmsavvy.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "user_contact")
public class UserContPersonDTO {
	public boolean isActive;
	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}
	public String CONTACT_PERSON;
	public String CONTACT_NO;
	public String CONTACT_SOURCE;
	public String ADDRESS;
	public String ADDRESS_SOURCE;
	public String EMAIL_ID;
    public String ID;
	@Id
	@Column(name = "id")
	@GeneratedValue(generator="system-uuid")
	@GenericGenerator(name="system-uuid", strategy = "uuid")
	public String getID() {
		return ID;
	}

	public void setID(String iD) {
		ID = iD;
	}
	public LeadDTO dto;
	@ManyToOne
	@JoinColumn(name = "lead_id")
	public LeadDTO getDto() {
		return dto;
	}

	public void setDto(LeadDTO dto) {
		this.dto = dto;
	}

	public String getCONTACT_PERSON() {
		return CONTACT_PERSON;
	}

	public void setCONTACT_PERSON(String cONTACT_PERSON) {
		CONTACT_PERSON = cONTACT_PERSON;
	}

	public String getCONTACT_NO() {
		return CONTACT_NO;
	}

	public void setCONTACT_NO(String cONTACT_NO) {
		CONTACT_NO = cONTACT_NO;
	}

	public String getCONTACT_SOURCE() {
		return CONTACT_SOURCE;
	}

	public void setCONTACT_SOURCE(String cONTACT_SOURCE) {
		CONTACT_SOURCE = cONTACT_SOURCE;
	}

	public String getADDRESS() {
		return ADDRESS;
	}

	public void setADDRESS(String aDDRESS) {
		ADDRESS = aDDRESS;
	}

	public String getADDRESS_SOURCE() {
		return ADDRESS_SOURCE;
	}

	public void setADDRESS_SOURCE(String aDDRESS_SOURCE) {
		ADDRESS_SOURCE = aDDRESS_SOURCE;
	}

	public String getEMAIL_ID() {
		return EMAIL_ID;
	}

	public void setEMAIL_ID(String eMAIL_ID) {
		EMAIL_ID = eMAIL_ID;
	}

}
