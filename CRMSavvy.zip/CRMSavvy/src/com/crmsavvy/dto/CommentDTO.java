package com.crmsavvy.dto;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
@Entity
@Table(name = "CommentDTO")
public class CommentDTO {
	@Id
	@Column(name = "id")
	@GeneratedValue(generator = "system-uuid")
	@GenericGenerator(name = "system-uuid", strategy = "uuid")
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName_of_Person() {
		return name_of_Person;
	}

	public void setName_of_Person(String name_of_Person) {
		this.name_of_Person = name_of_Person;
	}

	public String getEmail_of_person() {
		return email_of_person;
	}

	public void setEmail_of_person(String email_of_person) {
		this.email_of_person = email_of_person;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getComment_date() {
		return comment_date;
	}

	public void setComment_date(String comment_date) {
		this.comment_date = comment_date;
	}
	@ManyToOne
	@JoinColumn(name = "lead_id")
	public LeadDTO getDto() {
		return dto;
	}

	public void setDto(LeadDTO dto) {
		this.dto = dto;
	}
public String ContactNum_email;
	public String getContactNum_email() {
	return ContactNum_email;
}

public void setContactNum_email(String contactNum_email) {
	ContactNum_email = contactNum_email;
}
	public String id;
	public String name_of_Person;
	public String email_of_person;
	public String comment;
	public String comment_date;
	public String getSpoke_To() {
		return Spoke_To;
	}

	public void setSpoke_To(String spoke_To) {
		Spoke_To = spoke_To;
	}

	public String getStatus() {
		return Status;
	}

	public void setStatus(String status) {
		Status = status;
	}

	public String Spoke_To;
	public String Status;
	public LeadDTO dto;


}
