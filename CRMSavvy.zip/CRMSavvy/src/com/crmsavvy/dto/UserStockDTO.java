package com.crmsavvy.dto;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "userStock")
public class UserStockDTO {
	@Id
	@Column(name = "id")
	@GeneratedValue(generator = "system-uuid")
	@GenericGenerator(name = "system-uuid", strategy = "uuid")
	public String getID() {
		return ID;
	}

	public void setID(String iD) {
		ID = iD;
	}

	public String ID;
	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public String getFolioNum() {
		return FolioNum;
	}

	public void setFolioNum(String folioNum) {
		FolioNum = folioNum;
	}

	public String Name;
	public String FolioNum;
	public int count;
	public float price;
	public String mention_if_in_IEPF;
	public int no_of_stocks;
	public float CMP;
	public float Valuation;
	public LeadDTO dto;

	@ManyToOne
	@JoinColumn(name = "lead_id")
	public LeadDTO getDto() {
		return dto;
	}

	public void setDto(LeadDTO dto) {
		this.dto = dto;
	}

	public int getLeadId() {
		return leadId;
	}

	public void setLeadId(int leadId) {
		this.leadId = leadId;
	}

	public int leadId;

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public String getMention_if_in_IEPF() {
		return mention_if_in_IEPF;
	}

	public void setMention_if_in_IEPF(String mention_if_in_IEPF) {
		this.mention_if_in_IEPF = mention_if_in_IEPF;
	}

	public int getNo_of_stocks() {
		return no_of_stocks;
	}

	public void setNo_of_stocks(int no_of_stocks) {
		this.no_of_stocks = no_of_stocks;
	}

	public float getCMP() {
		return CMP;
	}

	public void setCMP(float cMP) {
		CMP = cMP;
	}

	public float getValuation() {
		return Valuation;
	}

	public void setValuation(float valuation) {
		Valuation = valuation;
	}
	public String gettAdressAsperCompany() {
		return tAdressAsperCompany;
	}

	public void settAdressAsperCompany(String tAdressAsperCompany) {
		this.tAdressAsperCompany = tAdressAsperCompany;
	}

	public String tAdressAsperCompany;


}
