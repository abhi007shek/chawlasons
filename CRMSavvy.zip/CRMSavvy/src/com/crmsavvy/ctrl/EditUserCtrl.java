package com.crmsavvy.ctrl;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.crmsavvy.service.UserService;

/**
 * Servlet implementation class EditUserCtrl
 */
@WebServlet("/EditUserCtrl")
public class EditUserCtrl extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public EditUserCtrl() {
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String userID;
		String Name;
		String role;
		String stockType;
		String email;
		userID = request.getParameter("userid");
		Name = request.getParameter("Full_Name");
		role = request.getParameter("Role");
		stockType = request.getParameter("Type");
		email = request.getParameter("Email");
		UserService userService = new UserService();
		userService.editUser(userID, Name, role, stockType, email);
		request.getRequestDispatcher("/MyTeam.jsp").forward(request, response);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
	}

}
