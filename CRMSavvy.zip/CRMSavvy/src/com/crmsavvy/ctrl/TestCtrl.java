package com.crmsavvy.ctrl;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.crmsavvy.dto.LeadDTO;
import com.crmsavvy.dto.UserDTO;
import com.crmsavvy.service.LeadService;
import com.crmsavvy.service.UserService;

/**
 * Servlet implementation class TestCtrl
 */
@WebServlet("/MySetting.html")
public class TestCtrl extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public TestCtrl() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		String name = null;
		name = request.getParameter("user");
		LeadService leadService = new LeadService();
		List<LeadDTO> relatedLeadList = new ArrayList();
		List<Integer> maxRelSubLeadID = new ArrayList<Integer>();
		LeadDTO dto = new LeadDTO();
		try {
			dto = leadService.getLead(name);
			 SimpleDateFormat formatter = new SimpleDateFormat("EEEE, dd/MM/yyyy HH:mm:ss a");
		        String dateInString = "Friday, Jun 7, 2013 12:10:56 PM";

		        try {

		            Date date = formatter.parse(dto.getNext_action_date());
		            System.out.println(date);
		            System.out.println(formatter.format(date));
		            dto.setNext_action_date(formatter.format(date));
		        } catch (ParseException e) {
		            e.printStackTrace();
		        }
			
			System.out.println("LEadod " + dto.getLeadId());
			relatedLeadList = leadService.getRelatedLead(dto.getLeadId(), dto.getSubLead());
			System.out.println("relatedLeadList.size()");
			maxRelSubLeadID.add(dto.getSubLead());
			for (LeadDTO dto2 : relatedLeadList) {
				maxRelSubLeadID.add(dto2.getSubLead());
			}

			System.out.println("MAX SUB LEAD - " + Collections.max(maxRelSubLeadID));
			System.out.println(relatedLeadList.size());
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		HttpSession session = request.getSession();
		UserDTO userDTO = (UserDTO) session.getAttribute("user");
		RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/profile.jsp");
		request.setAttribute("MAXSUBLEAD", Collections.max(maxRelSubLeadID));
		
		request.setAttribute("allUsersList", UserService.allUsersList);
		request.setAttribute("LoginService", userDTO);
		request.setAttribute("relatedLeadList", relatedLeadList);// list of
																	// related
																	// list
		request.setAttribute("data", dto);
		dispatcher.forward(request, response);

		// response.getWriter().append("Served at:
		// ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
