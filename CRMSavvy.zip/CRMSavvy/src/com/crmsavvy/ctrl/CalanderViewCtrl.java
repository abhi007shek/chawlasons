package com.crmsavvy.ctrl;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAccessor;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.crmsavvy.dto.LeadDTO;
import com.crmsavvy.dto.UserDTO;
import com.crmsavvy.service.LeadService;
import com.crmsavvy.service.LoginService;

/**
 * Servlet implementation class CalanderViewCtrl
 */
@WebServlet("/calendar.html")
public class CalanderViewCtrl extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public CalanderViewCtrl() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session = request.getSession(); // reuse
		// existing
		// session
		// if
		// exist
		// or create
		// one 
		UserDTO userDTO= (UserDTO) session.getAttribute("user");
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		LocalDateTime now = LocalDateTime.now();
		System.out.println(dtf.format(now));
		String today = dtf.format(now);
		System.out.println("today - " + today);
		LeadService leadService = new LeadService();
		Set<LeadDTO> leadDTOs = new HashSet<LeadDTO>();
		int openLeads = 0;

		int toDaysLeads = 0;
		int overDueLeads = 0;
		int dueleads = 0;
		int notcontacted = 0;
		int closeLeads = 0;

		// 2018-02-25 //YYYY-MM-DD
		leadDTOs = leadService.loadLeadCalander(userDTO);
		// totalLeads = leadDTOs.size();

		SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");

		Date date1 = null;
		try {
			date1 = format1.parse(today);
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		for (LeadDTO dto : leadDTOs) {
			Date date;
			try {
				date = format1.parse(dto.getNext_action_date());

				if (date1.after(date)) {
					System.out.println("Date1 is after Date2");
					overDueLeads++;
				}

				if (date1.before(date)) {
					dueleads++;
					System.out.println("Date1 is before Date2");
				}

				if (date1.equals(date)) {
					toDaysLeads++;
				}

			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(dto.getStatus().equals("NOT CONTACTED")){
				notcontacted++;
			}
			if (dto.getStatus().equals("CONTACTED-CONVERTED AND SENT TO WIP")) {
				closeLeads++;
			} 
			

		}
		request.setAttribute("leadDTOs", leadDTOs);
		
		request.setAttribute("TodaysLeads", toDaysLeads);
		request.setAttribute("OpenLeads", dueleads);
		request.setAttribute("overDueLeads", overDueLeads);
		request.setAttribute("CloseLeads", closeLeads);
		request.setAttribute("notcontacted", notcontacted);
		

		request.setAttribute("LoginService", userDTO);
		request.getRequestDispatcher("/WEB-INF/calendar.jsp").forward(request, response);

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		LocalDateTime now = LocalDateTime.now();
		System.out.println(dtf.format(now));
		String today = dtf.format(now);
		LeadService leadService = new LeadService();
		Set<LeadDTO> leadDTOs = new HashSet<LeadDTO>();
		int openLeads = 0;
		int toDaysLeads = 0;
		int closeLeads = 0;
		// 2018-02-25 //YYYY-MM-DD
		HttpSession session = request.getSession(); // reuse
		// existing
		// session
		// if
		// exist
		// or create
		// one 
		UserDTO userDTO= (UserDTO) session.getAttribute("user");
		leadDTOs = leadService.loadLeadCalander(userDTO);
		// totalLeads = leadDTOs.size();
		for (LeadDTO dto : leadDTOs) {
			if (dto.getNext_action_date().equals(today)) {
				toDaysLeads++;
			}
			if (dto.getStatus().equals("CLOSE AND CONVERTED")) {
				closeLeads++;
			} else {
				openLeads++;
			}

		}
		request.setAttribute("leadDTOs", leadDTOs);
		request.setAttribute("TodaysLeads", toDaysLeads);
		request.setAttribute("OpenLeads", openLeads);
		request.setAttribute("CloseLeads", closeLeads);
		request.getRequestDispatcher("/WEB-INF/calendar.jsp").forward(request, response);

	}

}
