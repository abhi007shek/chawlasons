package com.crmsavvy.ctrl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.crmsavvy.dto.LeadDTO;
import com.crmsavvy.dto.UserDTO;
import com.crmsavvy.service.LeadService;
import com.crmsavvy.service.LoginService;
import com.crmsavvy.service.UserService;
import com.google.gson.Gson;

/**
 * Servlet implementation class WrongContactCtrl
 */
@WebServlet("/visitInfo.html")
public class WrongContactCtrl extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public WrongContactCtrl() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		LeadService leadService = new LeadService();
		ArrayList<LeadDTO> leadDTOs = new ArrayList<LeadDTO>();
		ArrayList<LeadDTO> leadDTOs2 = new ArrayList<LeadDTO>();

		leadDTOs = leadService.loadWrongCont();

		String CSV = "";
		Gson gson = new Gson();
		for (LeadDTO dtos : leadDTOs) {
			LeadDTO dtosToLoad = new LeadDTO();
			dtosToLoad.setId(dtos.getId());
			dtosToLoad.setLeadId(dtos.getLeadId());
			dtosToLoad.setSubLead(dtos.getSubLead());
			dtosToLoad.setResponsible_Person(dtos.getResponsible_Person());
			dtosToLoad.setFirst_Name(dtos.getFirst_Name());
			dtosToLoad.setFather_hus_name(dtos.getFather_hus_name());
			dtosToLoad.setAddress(dtos.getAddress());
			dtosToLoad.setCity(dtos.getCity());
			dtosToLoad.setCountry(dtos.getCountry());
			dtosToLoad.setPIN_Code(dtos.getPIN_Code());
			dtosToLoad.setCMP(dtos.getCMP());
			dtosToLoad.setNo_of_share(dtos.getNo_of_share());
			dtosToLoad.setFOLIO_NUMBER(dtos.getFOLIO_NUMBER());
			dtosToLoad.setIEPF(dtos.getIEPF());
			dtosToLoad.setName_of_compny(dtos.getName_of_compny());
			dtosToLoad.setJointHolder(dtos.getJointHolder());
			dtosToLoad.setAllotmentDate(dtos.getAllotmentDate());
			dtosToLoad.setStatus(dtos.getStatus());
			dtosToLoad.setLast_contacted_on(dtos.getLast_contacted_on());
			dtosToLoad.setComments_by_person_responsible_for_contacting(
					dtos.getComments_by_person_responsible_for_contacting());
			dtosToLoad.setNext_action_date(dtos.getNext_action_date());
			dtosToLoad.setComments_by_finder_if_any(dtos.getComments_by_finder_if_any());
			dtosToLoad.setContact_Found(dtos.getContact_Found());
			leadDTOs2.add(dtosToLoad);
		}
		if (leadDTOs2.size() > 0) {
			CSV = gson.toJson(leadDTOs2);
		}
		System.out.println(CSV);
		request.setAttribute("CSV", CSV);
		request.setAttribute("leadDTOs", leadDTOs);
		request.setAttribute("allUsersList", UserService.allUsersList);
		HttpSession session = request.getSession();
		UserDTO userDTO = (UserDTO) session.getAttribute("user");

		request.setAttribute("LoginService", userDTO);

		request.getRequestDispatcher("/WEB-INF/WrongContactList.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

	}

}
