package com.crmsavvy.ctrl;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.crmsavvy.dto.UserContPersonDTO;
import com.crmsavvy.dto.UserDTO;
import com.crmsavvy.service.ContactService;
import com.crmsavvy.service.LoginService;

/**
 * Servlet implementation class CreateContact
 */
@WebServlet("/CreateContact")
public class CreateContact extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public CreateContact() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		/**
		 * CONTACT_PERSON CONTACT_NO CONTACT_SOURCE ADDRESS ADDRESS_SOURCE
		 * EMAIL_ID,leadDto
		 */
		HttpSession session = request.getSession();
		UserDTO userDTO = (UserDTO) session.getAttribute("user");
		UserContPersonDTO contPersonDTO = new UserContPersonDTO();
		contPersonDTO.setCONTACT_PERSON(request.getParameter("CONTACT_PERSON"));
		contPersonDTO.setCONTACT_NO(request.getParameter("CONTACT_NO"));
		contPersonDTO.setCONTACT_SOURCE(request.getParameter("CONTACT_SOURCE"));
		contPersonDTO.setADDRESS(request.getParameter("ADDRESS"));
		contPersonDTO.setADDRESS_SOURCE(request.getParameter("ADDRESS_SOURCE"));
		contPersonDTO.setEMAIL_ID(request.getParameter("EMAIL_ID"));
		contPersonDTO.setActive(true);
		String leadId = request.getParameter("leadDto");
		ContactService contactService = new ContactService();
		contactService.createContact(contPersonDTO, leadId);
		request.setAttribute("LoginService", userDTO);

		RequestDispatcher dispatcher = request.getRequestDispatcher("/MySetting.html?user=" + leadId);
		// request.setAttribute("user", leadId);
		dispatcher.forward(request, response);
		// doGet(request, response);
	}

}
