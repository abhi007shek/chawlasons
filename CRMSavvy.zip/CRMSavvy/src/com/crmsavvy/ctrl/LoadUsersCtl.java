package com.crmsavvy.ctrl;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.crmsavvy.dto.UserDTO;
import com.crmsavvy.service.LoginService;
import com.crmsavvy.service.UserService;

@WebServlet("/MyTeam.jsp")
public class LoadUsersCtl extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		System.out.println("calling /MyTeam.html");
		HttpSession session = request.getSession();
		UserDTO userDTO= (UserDTO) session.getAttribute("user");
		
		// UserService service= new UserService();
		List<UserDTO> productList = new ArrayList();
		productList = UserService.allUsersList;
		// all the necessary code to obtain the list of products
		// store it as request attribute
		request.setAttribute("LoginService", userDTO);

		request.setAttribute("productList", productList);
		// forward to the desired view
		// this is the real JSP that has the content to display to user
		// request.getRequestDispatcher("/WEB-INF/index.jsp").forward(request,
		// response);
		request.getRequestDispatcher("/WEB-INF/MyUser.jsp").forward(request, response);

	}
}
