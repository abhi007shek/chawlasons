package com.crmsavvy.ctrl;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.crmsavvy.dto.ParentStockDTO;
import com.crmsavvy.dto.UserDTO;
import com.crmsavvy.service.FileUploadService;
import com.crmsavvy.service.LoginService;
import com.crmsavvy.service.UserService;

@WebServlet("/BhavCopyList.html")
public class LoadBhavCopy extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)
	        throws IOException, ServletException {
		HttpSession session = request.getSession();
		UserDTO userDTO= (UserDTO) session.getAttribute("user");
		String propsFileName = getServletContext().getRealPath("/WEB-INF/properties/lastupdate.properties");
		FileInputStream configStream = new FileInputStream(propsFileName);
		Properties props = new Properties();
		props.load(configStream);
		request.setAttribute("lastupdate", props.getProperty("lastupdate"));

		System.out.println(props.getProperty("lastupdate"));
		configStream.close();

		if (userDTO == null) {
			request.getRequestDispatcher("/login.jsp").forward(request, response);

		}
		System.out.println("calling /BhavCopyList.html");  
	FileUploadService uploadService = new FileUploadService();
	     List<ParentStockDTO> productList = new ArrayList();
	     try {
			 productList = uploadService.getParentDTO();
		} catch (SQLException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	        //all the necessary code to obtain the list of products
	        //store it as request attribute
			request.setAttribute("LoginService", LoginService.dto);
	     request.setAttribute("productList", productList);
	        //forward to the desired view
	        //this is the real JSP that has the content to display to user
	     //   request.getRequestDispatcher("/WEB-INF/index.jsp").forward(request, response);
	       request.getRequestDispatcher("/WEB-INF/BhavCopyList.jsp").forward(request, response);

	}
}
