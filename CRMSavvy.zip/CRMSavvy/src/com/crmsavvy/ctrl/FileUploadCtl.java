package com.crmsavvy.ctrl;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.crmsavvy.dto.LeadDTO;
import com.crmsavvy.dto.ParentStockDTO;
import com.crmsavvy.dto.UserContPersonDTO;
import com.crmsavvy.dto.UserDTO;
import com.crmsavvy.dto.UserStockDTO;
import com.crmsavvy.service.FileUploadService;
import com.crmsavvy.service.LoginService;
import com.crmsavvy.service.UserService;

/**
 * Servlet implementation class FileUploadCtl
 */

@WebServlet("/FileUploadCtl")
public class FileUploadCtl extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public FileUploadCtl() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("calling");
		HttpSession session = request.getSession();
		UserDTO userDTO = (UserDTO) session.getAttribute("user");
		String propsFileName = getServletContext().getRealPath("/WEB-INF/properties/lastupdate.properties");
		FileInputStream configStream = new FileInputStream(propsFileName);
		Properties props = new Properties();
		props.load(configStream);

		System.out.println(props.getProperty("lastupdate"));
		configStream.close();

		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		LocalDateTime now = LocalDateTime.now();
		System.out.println(dtf.format(now));
		String today = dtf.format(now);
		System.out.println("today - " + today);
		SimpleDateFormat format1 = new SimpleDateFormat("dd-MM-yyyy");
		Date date1 = null;
		try {
			date1 = format1.parse(today);
		} catch (ParseException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}

		int totalData = 0;
		int sucessData = 0;
		FileUploadService fu = new FileUploadService();
		int maxLeadNumber = 0;
		try {
			maxLeadNumber = fu.getMaxId();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		if (LoginService.dto == null) {
			response.sendRedirect("index.jsp");
		}
		ArrayList<ParentStockDTO> arrayListParentStockDTO = new ArrayList<ParentStockDTO>();
		ArrayList<ParentStockDTO> arrayListLeadStatusDTO = new ArrayList<ParentStockDTO>();

		String contentType = request.getContentType();
		if ((contentType != null) && (contentType.indexOf("multipart/form-data") >= 0)) {
			DataInputStream in = new DataInputStream(request.getInputStream());
			int formDataLength = request.getContentLength();
			byte dataBytes[] = new byte[formDataLength];
			int byteRead = 0;
			int totalBytesRead = 0;

			while (totalBytesRead < formDataLength) {
				byteRead = in.read(dataBytes, totalBytesRead, formDataLength);
				totalBytesRead += byteRead;
			}
			String file = new String(dataBytes);
			String saveFile = file.substring(file.indexOf("filename=\"") + 10);
			// System.out.println("saveFile=" + saveFile);
			saveFile = saveFile.substring(saveFile.lastIndexOf("\\") + 1, saveFile.indexOf("\""));
			// System.out.println("saveFile" + saveFile);
			saveFile = file.substring(file.indexOf("filename=\"") + 10);
			saveFile = saveFile.substring(0, saveFile.indexOf("\n"));
			saveFile = saveFile.substring(saveFile.lastIndexOf("\\") + 1, saveFile.indexOf("\""));
			int lastIndex = contentType.lastIndexOf("=");
			String boundary = contentType.substring(lastIndex + 1, contentType.length());
			int pos;

			pos = file.indexOf("filename=\"");
			pos = file.indexOf("\n", pos) + 1;
			pos = file.indexOf("\n", pos) + 1;
			pos = file.indexOf("\n", pos) + 1;
			int boundaryLocation = file.indexOf(boundary, pos) - 4;
			int startPos = ((file.substring(0, pos)).getBytes()).length;
			int endPos = ((file.substring(0, boundaryLocation)).getBytes()).length;

			FileOutputStream fileOut = new FileOutputStream(saveFile);
			fileOut.write(dataBytes, startPos, (endPos - startPos));

			String line = null;
			String value = null;
			try {
				StringBuilder contents = new StringBuilder();
				BufferedReader input = new BufferedReader(new FileReader(saveFile));
				// FileUploadReqDTO dto = new FileUploadReqDTO();
				FileUploadService fileUploadService = new FileUploadService();
				ArrayList<ParentStockDTO> ParentStockDTOlist = fileUploadService.getParentDTO();
				Map<String, ParentStockDTO> ParentStockDTOMap = new HashMap<String, ParentStockDTO>();
				Map<String, ArrayList<LeadDTO>> LeadDTOMap = new HashMap<String, ArrayList<LeadDTO>>();
				Map<String, ArrayList<UserContPersonDTO>> LeadDTOMapWithCont = new HashMap<String, ArrayList<UserContPersonDTO>>();
				Map<String, String> LeadDTOMap2 = new HashMap<String, String>();

				Set<LeadDTO> lead2DTOlist = new HashSet<LeadDTO>();
				// LeadDTOMap.put("A1", new LeadDTO());
				for (ParentStockDTO stock : ParentStockDTOlist) {
					ParentStockDTOMap.put(stock.getSymbol(), stock);
				}
				System.out.println(ParentStockDTOMap.keySet());

				while ((line = input.readLine()) != null) {

					if (line.split(",").length <= 2) {
						// BACOPY UPLOAD
						// System.out.println("Uploading BA copy.......");

						if (!line.contains("SYMBOL")) {

							ParentStockDTO dto = new ParentStockDTO();
							String status = "";
							if (line.split(",")[0].length() < 0 || line.split(",")[1].length() < 0) {
								status = "Error";
							} else {

								status = "Sucess";
							}
							dto.setStatus(status);
							dto.setSymbol(line.split(",")[0]);
							dto.setClose(Float.parseFloat(line.split(",")[1]));
							arrayListParentStockDTO.add(dto);
							contents.append(line);

						}
					} else {
						// LEAD UPLOAD
						boolean hasContact = false;
						if (!line.contains("LEAD NO")) {
							totalData++;
							LeadDTO dto = new LeadDTO();
							String lines[] = line.split(",");
							// System.out.println("Uploading Lead.......");
							String status = "";
							if (lines[22] != null && lines[22] != "") {
								if (lines[22].equals("Yes")) {
									hasContact = true;
									System.out.println("contact  found");
								} else {
									hasContact = false;
									System.out.println("contact not found");
								}
							}

							for (int i = 0; i < line.split(",").length; i++) {
								// System.out.println("Line no 5"+lines[5]);

								dto = new LeadDTO();
								dto.setJointHolder(lines[14]);
								System.out.println("JointHolder: " + lines[14]);
								dto.setAllotmentDate(lines[15]);
								System.out.println("AllotmentDate: " + lines[15]);
								dto.setResponsible_Person(lines[2]);
								dto.setFirst_Name(lines[3]);
								dto.setFather_hus_name(lines[4]);
								dto.setAddress(lines[5]);
								dto.setCity(lines[6]);
								dto.setCountry(lines[7]);
								dto.setPIN_Code(lines[8]);
								dto.setName_of_compny(lines[9]);
								dto.setXsecond_joint_holder(lines[9]);
								  dto.setNo_of_share(Integer.parseInt(lines[10]));
								dto.setFOLIO_NUMBER(lines[11]);
								dto.setIEPF(lines[12]);
								UserStockDTO dto2 = new UserStockDTO();
								float val = 0;
								// System.out.println(lines[13]);
								if (ParentStockDTOMap.containsKey(lines[13].trim())) 
								{

									val = ParentStockDTOMap.get(lines[13].trim()).getClose()
											* (Integer.parseInt(lines[10]));

								}
								dto.setValuation(val);// CMP*no of
														// stock
								dto2.setCount(Integer.parseInt(lines[10]));
								dto2.setCMP(ParentStockDTOMap.get(lines[13].trim()).getClose());
								dto2.setNo_of_stocks(Integer.parseInt(lines[10]));
								dto.setCumulative_Valuation(val + "");// total
																		// of
																		// stock
																		// valuation
								dto.setCMP(lines[13]);
								dto.setComments_by_RTA_if_any(lines[16]);
								dto.setStatus(lines[17]);
								dto.setStatus("NOT CONTACTED");
								dto.setLast_contacted_on(lines[18]);
								dto.setComments_by_person_responsible_for_contacting(lines[19]);// comments
																								// by
																								// caller
								dto.setNext_action_date(lines[20]);
								dto.setComments_by_finder_if_any(lines[21]);
								dto.setContact_Found(lines[22]);
								dto.setSubLead(Integer.parseInt(lines[1]));
								// dto.setLeadId(Integer.parseInt(lines[1]));
								dto.setParentLead(lines[0]);
								// System.out.println("LeadDTOMap.get(lines[0].trim()");
								// System.out.println("hasContact -
								// "+hasContact);
								if (hasContact) {
									// has contact one or more
									UserContPersonDTO contPersonDTO = new UserContPersonDTO();
									Set<UserContPersonDTO> ContPersonDTOList = new HashSet<UserContPersonDTO>();
									// 23-28
									// System.out.println("creating contact");
									int k = 23;
									dto.setContact_Found(lines[23]);
									int s = 0;
									for (int j = 0; j < (lines.length - 23) / 6; j++) {
										contPersonDTO = new UserContPersonDTO();

										try {
											contPersonDTO.setCONTACT_PERSON(lines[k]);
											contPersonDTO.setCONTACT_NO(lines[k + 1]);
											contPersonDTO.setCONTACT_SOURCE(lines[k + 2]);
											contPersonDTO.setADDRESS(lines[k + 3]);
											contPersonDTO.setADDRESS_SOURCE(lines[k + 4]);
											contPersonDTO.setEMAIL_ID(lines[k + 5]);
											contPersonDTO.setActive(true);
											contPersonDTO.setDto(dto);
										} catch (Exception exception) {
											ParentStockDTO dto3 = new ParentStockDTO();
											dto3.setSymbol(line);
											dto3.setStatus("Sucess");
											arrayListLeadStatusDTO.add(dto3);
											exception.printStackTrace();
											System.out.println("Error");
											exception.printStackTrace();
										}
										ContPersonDTOList.add(contPersonDTO);

										k = k + 6;
									}
									System.out.println("ContPersonDTOList 0- " + ContPersonDTOList.size());
									dto.setContPersons(ContPersonDTOList);

								} // End of contact number multiple or not

							}
							// logic for parent lead
							if (LeadDTOMap2.containsKey(lines[0].trim())) {// related
																			// lead
								if (maxLeadNumber == 0) {
									maxLeadNumber = 1;
								}
								dto.setLeadId(maxLeadNumber);
								dto.setSubLead(Integer.parseInt(lines[1].trim()));
							} else {
								// single lead
								maxLeadNumber++;
								dto.setLeadId(maxLeadNumber);
								LeadDTOMap2.put(lines[0].trim(), "");

							}
							lead2DTOlist.add(dto);
						}

					}

				}
				System.out.println("lead2DTOlist - " + lead2DTOlist.size());
				for (LeadDTO dto : lead2DTOlist) {
					try {
						System.out.println("lead ID " + dto.getLeadId() + "sub lead - " + dto.getSubLead());
						if (dto.getContPersons() == null) {
						} else {
						}
					} catch (Exception exception) {
						ParentStockDTO dto2 = new ParentStockDTO();
						dto2.setSymbol(line);
						dto2.setStatus("Sucess");
						arrayListLeadStatusDTO.add(dto2);

						exception.printStackTrace();
						System.out.println("Error");
					}
				}
				value = contents.toString();

				System.out.println("arrayListParentStockDTO.size()  - " + arrayListParentStockDTO.size());
				if (arrayListParentStockDTO.size() > 0) {
					try {
						System.out.println("calling delete");
						fu.deleteAllParentStock();
					} catch (Exception exception) {
						exception.printStackTrace();
					}
					try {
						System.out.println("calling create");

						fu.uploadParaentDtoFile(arrayListParentStockDTO);
					} catch (Exception exception) {
						exception.printStackTrace();
					}

				}
				if (lead2DTOlist.size() > 0) {
					try {
						fu.uploadLead2(lead2DTOlist, ParentStockDTOMap);
						System.out.println("Sucess" + lead2DTOlist.size());
						sucessData = lead2DTOlist.size();
						System.out.println("Total recoreds - " + totalData);

						System.out.println("Error" + (totalData - lead2DTOlist.size()));
					} catch (Exception exception) {
						ParentStockDTO dto2 = new ParentStockDTO();
						dto2.setSymbol(line);
						dto2.setStatus("Sucess");
						arrayListLeadStatusDTO.add(dto2);

						exception.printStackTrace();
					}
				}
				if (lead2DTOlist.size() > 0) {
					request.setAttribute("data", arrayListLeadStatusDTO);

				} else {
					request.setAttribute("data", arrayListParentStockDTO);
				}

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		if (arrayListParentStockDTO.size() > 0) {
			props.setProperty("lastupdate", today + "");
			// save modified property file
			FileOutputStream output = new FileOutputStream(propsFileName);
			props.store(output, null);
			output.close();
		}

		request.setAttribute("SucessCount", sucessData);
		request.setAttribute("ErrorCount", (totalData - sucessData));
		request.setAttribute("TotalCount", totalData);

		request.setAttribute("allUsersList", UserService.allUsersList);
		request.setAttribute("LoginService", userDTO);

		RequestDispatcher dispatcher = request.getRequestDispatcher("FileUpload.jsp");
		// request.setAttribute("LoginService.dto", LoginService.dto);

		dispatcher.forward(request, response);

	}

}
