package com.crmsavvy.ctrl;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.crmsavvy.dto.LeadDTO;
import com.crmsavvy.dto.ParentStockDTO;
import com.crmsavvy.dto.UserDTO;
import com.crmsavvy.dto.UserStockDTO;
import com.crmsavvy.service.LoginService;
import com.crmsavvy.service.StockService;
import com.crmsavvy.service.UserService;

/**
 * Servlet implementation class NewStockCtrl
 */
@WebServlet("/NewStockCtrl")
public class NewStockCtrl extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public NewStockCtrl() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		// doGet(request, response);
		HttpSession session = request.getSession();
		UserDTO userDTO= (UserDTO) session.getAttribute("user");
		
		LeadDTO leadDTO = new LeadDTO();
		String leadId = request.getParameter("leadDto");
		System.out.println(leadId);
		StockService service = new StockService();
		ParentStockDTO parentStockDTO = new ParentStockDTO();
		System.out.println(request.getParameter("Company_Name"));
		System.out.println(request.getParameter("Folio_No"));
		System.out.println(request.getParameter("NoOfStock"));

		parentStockDTO = service.getParentStock(request.getParameter("Company_Name"));
		if (parentStockDTO == null) {
			System.out.println("company");
			response.getWriter().append("Company_Name not found ").append(request.getContextPath());
              
		} else {
			UserStockDTO stockDTO = new UserStockDTO();
			stockDTO.setFolioNum(request.getParameter("Folio_No"));
			stockDTO.setName(request.getParameter("Company_Name"));
			stockDTO.setCMP(parentStockDTO.getClose());
			stockDTO.setMention_if_in_IEPF(request.getParameter("IEPF"));
			stockDTO.setNo_of_stocks(Integer.parseInt(request.getParameter("NoOfStock")));
			stockDTO.setValuation(stockDTO.getNo_of_stocks() * stockDTO.getCMP());
			stockDTO.settAdressAsperCompany(request.getParameter("adressAsPerCompany"));
			System.out.println(stockDTO.getNo_of_stocks() * stockDTO.getCMP());
			/*
			 * Company_Name Folio_No IEPF NoOfStock
			 */
			try {
				service.createStock(leadId, stockDTO);
			} catch (ClassNotFoundException | SQLException e) { // TODO
																// Auto-generated
				e.printStackTrace();
			}
			RequestDispatcher dispatcher = request.getRequestDispatcher("/MySetting.html?user=" + leadId);
			request.setAttribute("allUsersList", UserService.allUsersList);
			request.setAttribute("LoginService", userDTO);

			// request.setAttribute("user", leadId);
			dispatcher.forward(request, response);

		}

	}

}
