package com.crmsavvy.ctrl;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.crmsavvy.dto.UserDTO;
import com.crmsavvy.service.UserService;

/**
 * Servlet implementation class TestServlet
 */
@WebServlet("/TestServlet")
public class TestServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public TestServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		System.out.println("CreateUserCtrl");
		PrintWriter out = response.getWriter();
		UserDTO userDTO = new UserDTO();
		/*
		 * public String name; public String role; public String user_name;
		 * public String e_mail; public Integer totalLead; public Integer
		 * openLead; public Integer closeLead; public String password;
		 */
		System.out.println("Full_name Role Email Password Retype_password");
		System.out.println("" + request.getParameter("Full_Name") + " " + request.getParameter("Role") + " "
				+ request.getParameter("Email") + " " + request.getParameter("Password") + " "
				+ request.getParameter("Retype_password"));

		userDTO.setName(request.getParameter("Full_Name"));
		userDTO.setRole(request.getParameter("Role"));
		userDTO.setUser_name(request.getParameter("Email"));
		userDTO.setE_mail(request.getParameter("Email"));
		userDTO.setIsactive(true);
		userDTO.setStocktype(request.getParameter("Type"));
		userDTO.setTotalLead(0);
		userDTO.setOpenLead(0);
		userDTO.setCloseLead(0);
		userDTO.setPassword(request.getParameter("Password"));
		// request.setAttribute("LoginService.dto", LoginService.dto);

		UserService userService = new UserService();
		try {
			if (userService.checkDuplicateUser(request.getParameter("Email"))) {
				request.setAttribute("Error", "Duplicate User Found with Email ID - " + request.getParameter("Email"));

			} else {
				userService.createUser(userDTO);

			}

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		request.getRequestDispatcher("/MyTeam.jsp").forward(request, response);
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: abhi").append(request.getContextPath());

		doGet(request, response);
	}

}
