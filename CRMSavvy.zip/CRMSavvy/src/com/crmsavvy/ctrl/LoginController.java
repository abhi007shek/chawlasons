package com.crmsavvy.ctrl;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URISyntaxException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.crmsavvy.dto.UserDTO;
import com.crmsavvy.service.LoginService;
import com.crmsavvy.service.UserService;

/**
 * Servlet implementation class Session
 */
@WebServlet("/LoginController")
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String error = "";
		String un = request.getParameter("uname");
		String pwd = request.getParameter("pass");
		LoginService service = new LoginService();
		UserService service2 = new UserService();
		String ip = request.getHeader("X-Forwarded-For");
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("Proxy-Client-IP");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("WL-Proxy-Client-IP");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("HTTP_CLIENT_IP");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("HTTP_X_FORWARDED_FOR");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getRemoteAddr();
		}
		System.out.println("IP- " + ip);

		try {
			UserDTO dto = service.login(un, pwd);

			if (dto != null) {
				if (dto.getId().length() > 0) {
					out.print("Welcome, " + un);

					HttpSession session = request.getSession(); // reuse
																// existing
																// session
																// if
																// exist
																// or create
																// one
					session.setAttribute("user", dto);
					LoginService.dto = dto;
					session.setMaxInactiveInterval(480 * 60); // 30 seconds
					response.sendRedirect("index.jsp");
				} else {
					RequestDispatcher rd = request.getRequestDispatcher("login.jsp");
					error = "Either user name or password is wrong.";
					request.setAttribute("error", error);
					rd.include(request, response);
				}
			} else {
				RequestDispatcher rd = request.getRequestDispatcher("login.jsp");
				error = "Either user name or password is wrong.";
				request.setAttribute("error", error);
				rd.include(request, response);

			}
		} catch (URISyntaxException | ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} // TODO Auto-generated method stub
	}
}