package com.crmsavvy.ctrl;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.crmsavvy.dto.CommentDTO;
import com.crmsavvy.dto.LeadDTO;
import com.crmsavvy.dto.UserDTO;
import com.crmsavvy.service.CommentService;
import com.crmsavvy.service.LeadService;
import com.crmsavvy.service.LoginService;
import com.crmsavvy.service.UserService;

/**
 * Servlet implementation class UpdateCommentCtrl
 */
@WebServlet("/UpdateCommentCtrl")
public class UpdateCommentCtrl extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public UpdateCommentCtrl() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		CommentService commentService = new CommentService();
		HttpSession session = request.getSession();
		UserDTO userDTO= (UserDTO) session.getAttribute("user");
		request.setAttribute("allUsersList", UserService.allUsersList);
		request.setAttribute("LoginService", userDTO);

		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		CommentDTO commentDTO = new CommentDTO();

		System.out.println("LoginService.dto.getName() - " + LoginService.dto.getName());
		//commentDTO.setEmail_of_person(LoginService.dto.getE_mail());
		commentDTO.setName_of_Person(LoginService.dto.getName());

		DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy hh:mm a");
		Date date = new Date();
		System.out.println(dateFormat.format(date)); // 2016/11/16 12:08:43
		commentDTO.setComment_date(dateFormat.format(date));
		String leadID = request.getParameter("leadDto");
		String cmtId = request.getParameter("commentId");
		commentDTO.setStatus(request.getParameter("Status"));
		System.out.println("spoke_to - "+request.getParameter("ContPerson"));
		commentDTO.setSpoke_To(request.getParameter("spoke_to"));
		commentDTO.setEmail_of_person(request.getParameter("ContPerson"));
		commentDTO.setComment(request.getParameter("Comments_by_person_responsible"));
		CommentService commentService = new CommentService();
		commentService.updateData(leadID, commentDTO, cmtId);

		request.setAttribute("allUsersList", UserService.allUsersList);
		request.setAttribute("LoginService", LoginService.dto);

		RequestDispatcher dispatcher = request.getRequestDispatcher("/MySetting.html?user=" + leadID);
		// request.setAttribute("user", leadId);
		dispatcher.forward(request, response);
	}
}
