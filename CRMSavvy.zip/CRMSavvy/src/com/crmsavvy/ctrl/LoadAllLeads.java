package com.crmsavvy.ctrl;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.crmsavvy.dto.LeadDTO;
import com.crmsavvy.dto.UserDTO;
import com.crmsavvy.service.FileUploadService;
import com.crmsavvy.service.LoginService;
import com.crmsavvy.service.UserService;

@WebServlet("/index.jsp")
public class LoadAllLeads extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {

		System.out.println("calling /index.jsp");
		HttpSession session = request.getSession();
		UserDTO userDTO = (UserDTO) session.getAttribute("user");
		if (userDTO == null) {
			System.out.println("LoginService.dto" + LoginService.dto);
			request.getRequestDispatcher("/login.jsp").forward(request, response);

		} else {
			String status = "";
			status = request.getParameter("status");
			FileUploadService service = new FileUploadService();
			ArrayList<LeadDTO> productList = new ArrayList<LeadDTO>();
			System.out.println("status - " + status);

			try {
				if (status == null) {
					status = "";
					productList = service.getAllLead(userDTO);

				}
				if (status.equals("Open_Leads")) {
					productList = service.getAllLeadWithstatus(status,userDTO);

				}
				if (status.equals("Overdue_Leads")) {
					System.out.println("Overdue_Leads");
					DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
					LocalDateTime now = LocalDateTime.now();
					System.out.println(dtf.format(now));
					SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
					ArrayList<LeadDTO> overdueList = new ArrayList<LeadDTO>();
					
					String today = dtf.format(now);
					System.out.println("today - " + today);
					Date date1 = null;
					try {
						date1 = format1.parse(today);
					} catch (ParseException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					productList = service.getAllLeadWithstatus(status,userDTO);
					for (LeadDTO dto : productList) {
						Date date;
						try {
							date = format1.parse(dto.getNext_action_date());
							if (date1.after(date)) {
				System.out.println("After");
								overdueList.add(dto);
							} else {

							}

							// remove(index)
						} catch (ParseException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

					}
					productList = overdueList;

				}
				if(status.equals("Due_Leads") ){
					System.out.println("Due_Leads");
					DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
					LocalDateTime now = LocalDateTime.now();
					System.out.println(dtf.format(now));
					SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
					ArrayList<LeadDTO> overdueList = new ArrayList<LeadDTO>();
					
					String today = dtf.format(now);
					System.out.println("today - " + today);
					Date date1 = null;
					try {
						date1 = format1.parse(today);
					} catch (ParseException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					productList = service.getAllLeadWithstatus(status,userDTO);
					for (LeadDTO dto : productList) {
						Date date;
						try {
							date = format1.parse(dto.getNext_action_date());
							if (date1.before(date)) {
				System.out.println("After");
								overdueList.add(dto);
							} else {

							}

							// remove(index)
						} catch (ParseException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

					}
					productList = overdueList;

					
				}
				if (status.equals("Close_Leads")) {

					productList = service.getAllLeadWithstatus(status,userDTO);

				}
				if(status.equals("Not_Contacted_Yet")){
					productList = service.getAllLeadWithstatus(status,userDTO);
					System.out.println(productList.size());
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			// all the necessary code to obtain the list of products
			// store it as request attribute
			request.setAttribute("LoginService", userDTO);
			request.setAttribute("productList", productList);
			// forward to the desired view
			// this is the real JSP that has the content to display to user
			// request.getRequestDispatcher("/WEB-INF/index.jsp").forward(request,
			// response);
			request.getRequestDispatcher("/WEB-INF/AllLead.jsp").forward(request, response);
		}
	}
}
