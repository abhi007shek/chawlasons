package com.crmsavvy.ctrl;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.crmsavvy.dto.CommentDTO;
import com.crmsavvy.dto.LeadDTO;
import com.crmsavvy.dto.UserDTO;
import com.crmsavvy.service.LeadService;
import com.crmsavvy.service.LoginService;
import com.crmsavvy.service.UserService;

/**
 * Servlet implementation class UpdateLeadCtrl
 */
@WebServlet("/UpdateLeadCtrl")
public class UpdateLeadCtrl extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public UpdateLeadCtrl() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session = request.getSession();
		UserDTO userDTO = (UserDTO) session.getAttribute("user");

		String personResposible = request.getParameter("Responsible_Person");
		String contPersonTOinactive = request.getParameter("ContPerson");
		LeadDTO dto = new LeadDTO();
		System.out.println("personResposible  1  - " + request.getParameter("Responsible_Person"));

		System.out.println("Status - " + request.getParameter("Status"));
		System.out.println("Comments_by_finder - " + request.getParameter("Comments_by_finder"));
		System.out.println("Comments_by_RTA - " + request.getParameter("Comments_by_RTA"));
		CommentDTO commentDTO = null;
		String leadID = request.getParameter("leadDto");

		if (request.getParameter("Comments_by_finder") == null && request.getParameter("Comments_by_RTA") == null) {
			commentDTO = new CommentDTO();
			System.out.println("LoginService.dto.getName() - " + LoginService.dto.getName());
			//commentDTO.setEmail_of_person(LoginService.dto.getE_mail()); contact name will be here
			commentDTO.setName_of_Person(LoginService.dto.getName());

			DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy hh:mm a");
			Date date = new Date();
			System.out.println(dateFormat.format(date)); // 2016/11/16 12:08:43
			commentDTO.setComment_date(dateFormat.format(date));
			commentDTO.setStatus(request.getParameter("Status"));
			commentDTO.setSpoke_To(request.getParameter("spoke_to"));
			System.out.println("ContactNum_email->"+request.getParameter("ContactNum_email"));
            commentDTO.setContactNum_email(request.getParameter("ContactNum_email"));
			System.out.println("update action"+request.getParameter("ContactNum_email"));
			dto.setComments_by_person_responsible_for_contacting(request.getParameter("Comments_by_person_responsible"));
			commentDTO.setComment(request.getParameter("Comments_by_person_responsible"));
			dto.setComments_by_person_responsible_for_contacting(
					request.getParameter("Comments_by_person_responsible"));
			if (request.getParameter("Last_contacted_on").isEmpty()
					|| request.getParameter("Last_contacted_on") == null) {
				dto.setLast_contacted_on(dateFormat.format(date));

			} else {
				dto.setLast_contacted_on(request.getParameter("Last_contacted_on"));

			}
			dto.setNext_action_date(request.getParameter("Next_action_date"));
			System.out.println("personResposible - " + personResposible);
			if (personResposible.equals("Select Responsible Person") && personResposible != "") {
				// add responsible person to lead

			} else {
				System.out.println("personResposible if - " + personResposible);
				dto.setResponsible_Person(personResposible);
				dto.setAssignBy(userDTO.getName());
				dto.setAssginTo(dto.getResponsible_Person());
			}

		} else {
			System.out.println("update RTA");
			dto.setComments_by_finder_if_any(request.getParameter("Comments_by_finder"));
			dto.setComments_by_RTA_if_any(request.getParameter("Comments_by_RTA"));
		}
		dto.setStatus(request.getParameter("Status"));
		System.out.println(dto.getResponsible_Person());
		LeadService leadService = new LeadService();
		leadService.updateLead(leadID, dto, commentDTO, contPersonTOinactive);
		request.setAttribute("allUsersList", UserService.allUsersList);
		request.setAttribute("LoginService", userDTO);

		RequestDispatcher dispatcher = request.getRequestDispatcher("/MySetting.html?user=" + leadID);
		// request.setAttribute("user", leadId);
		dispatcher.forward(request, response);
	}

}
