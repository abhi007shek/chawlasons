package com.crmsavvy.ctrl;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.crmsavvy.dto.UserDTO;
import com.crmsavvy.service.FileUploadService;
import com.crmsavvy.service.LeadService;
import com.crmsavvy.service.UserService;

/**
 * Servlet implementation class DeleteRelatedLead
 */
@WebServlet("/DeleteRelatedLead")
public class DeleteRelatedLead extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public DeleteRelatedLead() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		FileUploadService fileUploadService = new FileUploadService();
		int max = 0;
		try {
			max = fileUploadService.getMaxId();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String leadId = request.getParameter("leadId");
		LeadService leadService = new LeadService();
		String id = leadService.deleteLead(leadId, max);
		RequestDispatcher dispatcher = request.getRequestDispatcher("MySetting.html?user=" + id);
		dispatcher.forward(request, response);

		// "MySetting.html?user="+id;
		// response.getWriter().append("Served at: id =
		// "+id).append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
