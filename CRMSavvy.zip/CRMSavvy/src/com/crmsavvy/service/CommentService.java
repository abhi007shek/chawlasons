package com.crmsavvy.service;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

import com.crmsavvy.dto.CommentDTO;
import com.crmsavvy.dto.LeadDTO;
import com.crmsavvy.dto.ParentStockDTO;
import com.crmsavvy.dto.UserStockDTO;
import com.mvc.util.DBConnection;

public class CommentService {
	public void updateData(String id, CommentDTO commentDTO, String commentID) {
		Configuration configuration = new Configuration().configure();
		ServiceRegistryBuilder registry = new ServiceRegistryBuilder();
		registry.applySettings(configuration.getProperties());
		ServiceRegistry serviceRegistry = registry.buildServiceRegistry();
		// builds a session factory from the service registry
		SessionFactory sessionFactory = configuration.buildSessionFactory(serviceRegistry);

		// obtains the session
		Session session = sessionFactory.openSession();// openSession();
		session.beginTransaction();

		// EAGER FETCHING WITH list()
		System.out.println("Printing with list()");
		Query q = session.createQuery("FROM com.crmsavvy.dto.CommentDTO where id='" + commentID + "'");
		List<CommentDTO> userStockDTOs = q.list();
		for (CommentDTO dto : userStockDTOs) {
			if (dto.getId().equals(commentID)) {
				dto.setComment(commentDTO.getComment());
				dto.setComment_date(commentDTO.getComment_date());
				dto.setEmail_of_person(commentDTO.getEmail_of_person());
				dto.setName_of_Person(commentDTO.getName_of_Person());
				dto.setSpoke_To(commentDTO.getSpoke_To());
				dto.getDto().setLast_contacted_on(dto.getComment_date());
				session.update(dto);
				System.out.println("dto.getDto().getLast_contacted_on()"+dto.getDto().getLast_contacted_on());
				session.update(dto.getDto());

			} // dto.getNo_of_stocks()
		}
		session.getTransaction().commit();
		session.close();
	}

	public void deleteData(String id) {
		/*
		 * DELETE FROM table WHERE condition;
		 */
		DBConnection connections = new DBConnection();
		Connection connection = null;
		try {
			connection = connections.createConnection();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Statement statement = null;
		try {
			statement = connection.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} //
		try {
			int i = statement.executeUpdate("DELETE FROM CommentDTO where id = '" + id + "'");
			System.out.println(i);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			statement.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
