package com.crmsavvy.service;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

import com.crmsavvy.dto.LeadDTO;
import com.crmsavvy.dto.ParentStockDTO;
import com.crmsavvy.dto.UserContPersonDTO;
import com.crmsavvy.dto.UserDTO;
import com.crmsavvy.dto.UserStockDTO;
import com.mvc.util.DBConnection;

public class FileUploadService {

	public void deleteAllParentStock() throws ClassNotFoundException, SQLException {
		DBConnection connections = new DBConnection();

		Connection connection = connections.createConnection();

		Statement stmt = null;
		try {
			stmt = connection.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		stmt.executeQuery("TRUNCATE parentStock");
		stmt.close();
		connection.close();
	}

	public void uploadParaentDtoFile(List<ParentStockDTO> parntDTOlst) throws SQLException {
		DBConnection connectionDB = new DBConnection();
		Connection con = null;
		try {
			con = connectionDB.createConnection();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// Create SQL statement
		String SQL = "INSERT INTO parentStock (symbol, close) " + "VALUES(?, ?)";

		// Create PrepareStatement object
		PreparedStatement pstmt = con.prepareStatement(SQL);
		System.out.println("parntDTOlst" + parntDTOlst.size());
		// Set auto-commit to false
		con.setAutoCommit(false);
		for (ParentStockDTO dto : parntDTOlst) {
			// System.out.println(dto);
			pstmt.setString(1, dto.getSymbol());
			pstmt.setFloat(2, dto.getClose());
			pstmt.addBatch();

		}
		int[] count = pstmt.executeBatch();
		// pstmt.closeOnCompletion();
		System.out.println(count);
		if (count.length > 0) {
			StockService service = new StockService();
			try {
				service.updateStock(parntDTOlst);
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		// Explicitly commit statements to apply changes
		con.commit();// TODO:uncomment live save to database
		con.close();

	}

	public void uploadLead2(Set<LeadDTO> lead2DTOlist, Map<String, ParentStockDTO> ParentStockDTOMap) {

		Configuration configuration = new Configuration().configure();
		ServiceRegistryBuilder registry = new ServiceRegistryBuilder();
		registry.applySettings(configuration.getProperties());
		ServiceRegistry serviceRegistry = registry.buildServiceRegistry();

		// builds a session factory from the service registry
		SessionFactory sessionFactory = configuration.buildSessionFactory(serviceRegistry);

		// obtains the session
		Session session = sessionFactory.openSession();// openSession();
		session.beginTransaction();

		for (LeadDTO dto : lead2DTOlist) {
			UserStockDTO stockDTO = new UserStockDTO();
			Set<UserStockDTO> UserStockDTOSet = new HashSet<UserStockDTO>();
			/*
			 * 
			 * public String Name; public String FolioNum; public int count;
			 * public float price; public String mention_if_in_IEPF; public int
			 * no_of_stocks; public float CMP; public float Valuation; public
			 * LeadDTO dto;
			 */
			stockDTO.setFolioNum(dto.getFOLIO_NUMBER());
			stockDTO.setCount(dto.getNo_of_share());
			stockDTO.setNo_of_stocks(dto.getNo_of_share());
			stockDTO.setCMP(ParentStockDTOMap.get(dto.getCMP()).getClose());
			stockDTO.setValuation(ParentStockDTOMap.get(dto.getCMP()).getClose() * dto.getNo_of_share());
			stockDTO.setMention_if_in_IEPF(dto.getIEPF());
			stockDTO.setName(dto.getCMP());
			stockDTO.settAdressAsperCompany(dto.getAddress() + ", " + dto.getCity() + ", " + dto.getCountry() + ".");
			stockDTO.setDto(dto);
			UserStockDTOSet.add(stockDTO);
			dto.setStocks(UserStockDTOSet);
			session.save(dto);
		}

		System.out.println("close");
		session.getTransaction().commit();
		session.close();

	}

	public void uploadLead(Map<String, ArrayList<LeadDTO>> LeadDTOMap,
			Map<String, ArrayList<UserContPersonDTO>> LeadDTOMapWithCont) {
		System.out.println("------------------LeadDTOMapWithCont.size()---------------------------------");
		System.out.println(LeadDTOMapWithCont.size());
		System.out.println("-------------------LeadDTOMap.size()--------------------------------");
		System.out.println(LeadDTOMap.size());
		String SQL = "INSERT INTO leads (SUB_LEAD_NO,Responsible_Person,NAME_OF_SHAREHOLDER,FATHER_HUSBAND_NAME,ADDRES,CITY,COUNTRY,PINCODE,NAME_OF_COMPANY,NO_OF_SHARES,FOLIO_NUMBER_OF_SECURITIES,IEPF,CMP,VALUATION,CUMULATIVE_VALUATION,COMMENTS_BY_RTA,STATUS,LAST_CONTACTED_ON,COMMENTS_BY_CALLER,NEXT_ACTION_DATE,REMARKS_BY_FINDER,CONTACT_FOUND,PARENT_LEAD_ID) "
				+ "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		String SQL2 = "INSERT INTO user_contact(CONTACT_PERSON,CONTACT_NO,CONTACT_SOURCE,ADDRESS_SOURCE,EMAIL_ID,PARENT_LEAD_ID) VALUES(?,?,?,?,?,?)";

		DBConnection connectionDB = new DBConnection();
		PreparedStatement pstmt;

		Connection con = null;
		try {
			con = connectionDB.createConnection();
			pstmt = con.prepareStatement(SQL);
			// System.out.println(LeadDTOMap.keySet());
			for (String key : LeadDTOMap.keySet()) {
				for (LeadDTO leadDTO : LeadDTOMap.get(key)) {

					if (LeadDTOMapWithCont.containsKey(key)) {
						System.out.println("----contacts----");
					}

					if (leadDTO.getParentLead().length() > 0) {
						System.out.println("ParentLead()");

					} else {
						pstmt.setString(1, key);
						pstmt.setString(2, leadDTO.getResponsible_Person());
						pstmt.setString(3, leadDTO.getFirst_Name());
						pstmt.setString(4, leadDTO.getFather_hus_name());
						// System.out.println(leadDTO.getAddress());
						pstmt.setString(5, leadDTO.getAddress());
						pstmt.setString(6, leadDTO.getCity());
						pstmt.setString(7, leadDTO.getCountry());
						pstmt.setString(8, leadDTO.getPIN_Code());
						pstmt.setString(9, leadDTO.getName_of_compny());
						pstmt.setString(10, "" + leadDTO.getNo_of_share());
						pstmt.setString(11, leadDTO.getFOLIO_NUMBER());
						if (leadDTO.getIEPF().length() > 0) {
							pstmt.setString(12, leadDTO.getIEPF());

						} else {
							pstmt.setString(12, "NO");

						}
						pstmt.setString(13, leadDTO.getCMP());
						pstmt.setString(14, "" + leadDTO.getValuation());
						pstmt.setString(15, "" + leadDTO.getCumulative_Valuation());
						pstmt.setString(16, "" + leadDTO.getComments_by_RTA_if_any());
						pstmt.setString(17, "" + "NOT CONTACTED");
						pstmt.setString(18, "" + leadDTO.getLast_contacted_on());
						pstmt.setString(19, "" + leadDTO.getComments_by_person_responsible_for_contacting());
						pstmt.setString(20, "" + leadDTO.getNext_action_date());
						pstmt.setString(21, "" + leadDTO.getComments_by_finder_if_any());
						pstmt.setString(22, "" + leadDTO.getContact_Found());
						pstmt.setString(23, "" + "NA");// parentLEad

						pstmt.addBatch();

					}
				}

			}
			int[] count = pstmt.executeBatch();
			// System.out.println("No of record inserted - "+count);
			// Explicitly commit statements to apply changes
			// con.commit();// TODO:uncomment live save to database
			con.close();

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			e.getNextException();
		}

	}

	public ArrayList<ParentStockDTO> getParentDTO() throws SQLException, ClassNotFoundException {
		DBConnection connectionDB = new DBConnection();
		Connection conn = null;
		// deleteParentDto();
		try {
			conn = connectionDB.createConnection();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		PreparedStatement stmt = conn.prepareStatement("SELECT * FROM parentStock ");
		// stmt.setString(1,ownerID );
		ResultSet resultSet = stmt.executeQuery();
		ArrayList<ParentStockDTO> reqList = new ArrayList<ParentStockDTO>();
		while (resultSet.next()) {
			ParentStockDTO dto = new ParentStockDTO();
			dto.setSymbol(resultSet.getString(1));
			dto.setClose(resultSet.getFloat(2));
			reqList.add(dto);
			// System.out.println(" sym - " + resultSet.getString(1));
			// System.out.println(" sym - " + resultSet.getFloat(2));

		}
		conn.close();
		return reqList;

	}

	public ArrayList<LeadDTO> getAllLead(UserDTO userDTO) throws SQLException {
		DBConnection connectionDB = new DBConnection();
		Connection conn = null;
		// deleteParentDto();
		try {
			conn = connectionDB.createConnection();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		PreparedStatement stmt = null;// conn.prepareStatement("SELECT * FROM
										// leads where responsible_person =
										// '"+userDTO.getUser_name()+"'");
		if (userDTO.getRole().equals("Admin")) {
			stmt = conn.prepareStatement("SELECT * FROM leads");
		} else {
			stmt = conn.prepareStatement(
					"SELECT * FROM leads where responsible_person = '" + userDTO.getUser_name() + "'");
		}
		// TODO Uniq ID will be ID+SUBID
		// stmt.setString(1,ownerID );
		ResultSet resultSet = stmt.executeQuery();
		ArrayList<LeadDTO> reqList = new ArrayList<LeadDTO>();
		Map<String, String> userMAp = new HashMap<String, String>();
		System.out.println("UserService.allUsersList" + UserService.allUsersList.size());
		for (UserDTO user : UserService.allUsersList) {
			userMAp.put(user.getE_mail(), user.getName());
		}
		while (resultSet.next()) {
			LeadDTO dto = new LeadDTO();
			System.out.println("---------------------------------------------");
			dto.setId(resultSet.getString(1));

			try {
				/*
				 * System.out.println(resultSet.getString(1));
				 * System.out.println(resultSet.getString(2));
				 * System.out.println(resultSet.getString(3));
				 * System.out.println("setResponsible_Person"+resultSet.
				 * getString(4));
				 * System.out.println("First_Name"+resultSet.getString(5));
				 * System.out.println(resultSet.getString(6));
				 * System.out.println(resultSet.getString(7));
				 * System.out.println(resultSet.getString(8));
				 * System.out.println(resultSet.getString(9));
				 * System.out.println(resultSet.getString(10));
				 * System.out.println(resultSet.getString(11));
				 * System.out.println(resultSet.getString(12));
				 * System.out.println(resultSet.getString(13));
				 * System.out.println(resultSet.getString(14));
				 * System.out.println(resultSet.getString(15));
				 * System.out.println(resultSet.getString(16));
				 * System.out.println(resultSet.getString(17));
				 * System.out.println(resultSet.getString(18));
				 * System.out.println(resultSet.getString(19));
				 * System.out.println(resultSet.getString(20));
				 * System.out.println(resultSet.getString(21));
				 * System.out.println(resultSet.getString(22));
				 * System.out.println(resultSet.getString(23));
				 */
			} catch (Exception exception) {
				exception.printStackTrace();
			}
			dto.setLeadId(Integer.parseInt(resultSet.getString(23)));
			System.out.println("Lead ID -" + resultSet.getString(23));
			dto.setResponsible_Person(userMAp.get(resultSet.getString(28)));
			dto.setFirst_Name(resultSet.getString(19));
			dto.setFather_hus_name(resultSet.getString(18));
			dto.setAddress(resultSet.getString(6));
			dto.setCity(resultSet.getString(11));
			dto.setCountry(resultSet.getString(16));
			dto.setPIN_Code(resultSet.getString(5));
			dto.setName_of_compny(resultSet.getString(2));
			dto.setNo_of_share(Integer.parseInt(resultSet.getString(26)));
			dto.setFOLIO_NUMBER(resultSet.getString(3));
			if (resultSet.getString(4).length() > 0) {
				dto.setIEPF("YES");

			} else {
				dto.setIEPF("NO");

			}
			dto.setCMP(resultSet.getString(2));
			dto.setValuation(Float.parseFloat(resultSet.getString(34)));
			dto.setType("listed");
			dto.setCumulative_Valuation(resultSet.getString(17));
			dto.setComments_by_RTA_if_any(resultSet.getString(12));
			dto.setStatus(resultSet.getString(31));
			dto.setLast_contacted_on(resultSet.getString(22));
			dto.setComments_by_person_responsible_for_contacting(resultSet.getString(14));
			dto.setNext_action_date(resultSet.getString(25));
			dto.setComments_by_finder_if_any(resultSet.getString(14));
			dto.setContact_Found(resultSet.getString(15));
			dto.setSubLead(resultSet.getInt(32));
			System.out.println("---------------------------------------------");
			reqList.add(dto);
		}
		conn.close();
		return reqList;
	}

	public ArrayList<LeadDTO> getAllLeadWithstatus(String status, UserDTO userDTO) throws SQLException {
		DBConnection connectionDB = new DBConnection();
		Connection conn = null;
		PreparedStatement stmt = null;
		System.out.println("status " + status);
		// deleteParentDto();
		try {
			conn = connectionDB.createConnection();

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (status.equals("Not_Contacted_Yet")) {
			System.out.println("Not_Contacted_Yet");
			status = "NOT CONTACTED";
			if (userDTO.getRole().equals("Admin")) {
				stmt = conn.prepareStatement("SELECT * FROM leads where status = '" + status + "'");

			} else {
				stmt = conn.prepareStatement("SELECT * FROM leads where status = '" + status
						+ "' AND responsible_person = '" + userDTO.getUser_name() + "'");

			}

		}
		if (status.equals("Overdue_Leads")) {
			System.out.println("Overdue_Leads- 2");
			if (userDTO.getRole().equals("Admin")) {
				stmt = conn.prepareStatement("SELECT * FROM leads");

			} else {
				stmt = conn.prepareStatement(
						"SELECT * FROM leads where responsible_person = '" + userDTO.getUser_name() + "'");

			}

		}
		if (status.equals("Close_Leads")) {
			status = "CONTACTED-CONVERTED AND SENT TO WIP";
			if (userDTO.getRole().equals("Admin")) {
				stmt = conn.prepareStatement("SELECT * FROM leads where status = '" + status + "'");

			} else {
				stmt = conn.prepareStatement("SELECT * FROM leads where status = '" + status
						+ "' AND responsible_person = '" + userDTO.getUser_name() + "'");

			}

		}
		if (status.equals("Due_Leads")) {
			status = "Due_Leads";
			if (userDTO.getRole().equals("Admin")) {
				stmt = conn.prepareStatement("SELECT * FROM leads");
			} else {
				stmt = conn.prepareStatement("SELECT * FROM leads where status = '" + status
						+ "AND responsible_person = '" + userDTO.getUser_name() + "'");
			}

		}
		// TODO Uniq ID will be ID+SUBID
		// stmt.setString(1,ownerID );
		ResultSet resultSet = stmt.executeQuery();
		ArrayList<LeadDTO> reqList = new ArrayList<LeadDTO>();
		Map<String, String> userMAp = new HashMap<String, String>();
		System.out.println("UserService.allUsersList" + UserService.allUsersList.size());
		for (UserDTO user : UserService.allUsersList) {
			userMAp.put(user.getE_mail(), user.getName());
		}
		while (resultSet.next()) {
			LeadDTO dto = new LeadDTO();
			System.out.println("---------------------------------------------");
			dto.setId(resultSet.getString(1));

			try {
				/*
				 * dto.setJointHolder(lines[14]);
				 * dto.setAllotmentDate(lines[15]);
				 * System.out.println(resultSet.getString(1));
				 * System.out.println(resultSet.getString(2));
				 * System.out.println(resultSet.getString(3));
				 * System.out.println("setResponsible_Person"+resultSet.
				 * getString(4));
				 * System.out.println("First_Name"+resultSet.getString(5));
				 * System.out.println(resultSet.getString(6));
				 * System.out.println(resultSet.getString(7));
				 * System.out.println(resultSet.getString(8));
				 * System.out.println(resultSet.getString(9));
				 * System.out.println(resultSet.getString(10));
				 * System.out.println(resultSet.getString(11));
				 * System.out.println(resultSet.getString(12));
				 * System.out.println(resultSet.getString(13));
				 * System.out.println(resultSet.getString(14));
				 * System.out.println(resultSet.getString(15));
				 * System.out.println(resultSet.getString(16));
				 * System.out.println(resultSet.getString(17));
				 * System.out.println(resultSet.getString(18));
				 * System.out.println(resultSet.getString(19));
				 * System.out.println(resultSet.getString(20));
				 * System.out.println(resultSet.getString(21));
				 * System.out.println(resultSet.getString(22));
				 * System.out.println(resultSet.getString(23));
				 */
			} catch (Exception exception) {
				exception.printStackTrace();
			}
			dto.setLeadId(Integer.parseInt(resultSet.getString(23)));
			System.out.println("Lead ID -" + resultSet.getString(23));
			dto.setResponsible_Person(userMAp.get(resultSet.getString(28)));
			dto.setFirst_Name(resultSet.getString(20));
			dto.setFather_hus_name(resultSet.getString(19));
			dto.setAddress(resultSet.getString(6));
			dto.setCity(resultSet.getString(12));
			dto.setCountry(resultSet.getString(17));
			dto.setPIN_Code(resultSet.getString(5));
			dto.setName_of_compny(resultSet.getString(2));
			dto.setNo_of_share(Integer.parseInt(resultSet.getString(26)));
			dto.setFOLIO_NUMBER(resultSet.getString(3));
			if (resultSet.getString(4).length() > 0) {
				dto.setIEPF("YES");

			} else {
				dto.setIEPF("NO");

			}
			dto.setCMP(resultSet.getString(2));
			dto.setValuation(Float.parseFloat(resultSet.getString(34)));
			dto.setType("listed");
			dto.setCumulative_Valuation(resultSet.getString(18));
			dto.setComments_by_RTA_if_any(resultSet.getString(13));
			dto.setStatus(resultSet.getString(31));
			dto.setLast_contacted_on(resultSet.getString(22));
			dto.setComments_by_person_responsible_for_contacting(resultSet.getString(15));
			dto.setNext_action_date(resultSet.getString(25));
			dto.setComments_by_finder_if_any(resultSet.getString(14));
			dto.setContact_Found(resultSet.getString(16));
			dto.setSubLead(resultSet.getInt(32));
			System.out.println("---------------------------------------------");
			reqList.add(dto);
		}
		conn.close();
		return reqList;
	}

	public int getMaxId() throws SQLException {
		// SELECT id, name, MAX(salary) FROM COMPANY GROUP BY id, name;
		DBConnection connectionDB = new DBConnection();
		Connection conn = null;
		// deleteParentDto();
		try {
			conn = connectionDB.createConnection();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		PreparedStatement stmt = conn.prepareStatement("SELECT MAX(leadId) FROM leads");
		// TODO Uniq ID will be ID+SUBID
		// stmt.setString(1,ownerID );
		ResultSet resultSet = stmt.executeQuery();
		int count = 0;
		while (resultSet.next()) {
			count = resultSet.getInt(1);
		}
		System.out.println(count);
		conn.close();
		return count;
	}

	public static void main(String[] args) throws SQLException, ClassNotFoundException {
		// TODO Auto-generated method stub
		FileUploadService fileUploadService = new FileUploadService();
		fileUploadService.getAllLeadWithstatus("CONTACTED-CONVERTED AND SENT TO WIP", null);

	}

}
