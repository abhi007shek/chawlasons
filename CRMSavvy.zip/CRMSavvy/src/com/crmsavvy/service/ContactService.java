package com.crmsavvy.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

import com.crmsavvy.dto.LeadDTO;
import com.crmsavvy.dto.UserContPersonDTO;
import com.mvc.util.DBConnection;

public class ContactService {
	public void createContact(UserContPersonDTO contPersonDTO, String leadID) {
		SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
		;
		// ServiceRegistryBuilder registry = new ServiceRegistryBuilder();
		// registry.applySettings(configuration.getProperties());
		// ServiceRegistry serviceRegistry = registry.
		// SessionFactory sessionFactory =
		// configuration.buildSessionFactory(serviceRegistry);
		LeadDTO dto = new LeadDTO();

		Session session = sessionFactory.openSession();// openSession();
		Transaction tx = session.beginTransaction();

		System.out.println("--");
		dto = (LeadDTO) session.load("com.crmsavvy.dto.LeadDTO", leadID);
		contPersonDTO.setDto(dto);
		Set<UserContPersonDTO> contPersonDTOs = new HashSet<UserContPersonDTO>();
		contPersonDTOs.add(contPersonDTO);
		dto.setContPersons(contPersonDTOs);
		System.out.println(dto.getContPersons().size());
		session.update(dto);
		// session.save(stockDTO);
		tx.commit();
		System.out.println("saved");
		session.close();

	}

	public void updateContact(String id) {
		String SQL = "UPDATE user_contact SET active = true WHERE ID='" + id + "'";

		DBConnection connectionDB = new DBConnection();
		PreparedStatement pstmt;

		Connection con = null;
		try {
			con = connectionDB.createConnection();
			pstmt = con.prepareStatement(SQL);
			pstmt.executeQuery();
			con.close();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	public void editContact(String userid,String Name,String Mobile,String Email){
		System.out.println("updating contact");
		String SQL = "UPDATE user_contact SET contact_person=?,contact_no=?,address=? WHERE ID=?";
		/*1 id  	
		2 address *   	
		3 address_source  	
		4 contact_no *   	
		5 contact_person * 	
		6 contact_source  	
		7 email_id  	
		8 active  	
		9 lead_id  	
		*/
		System.out.println(Name);
		System.out.println(Mobile);
		System.out.println(Email);
		System.out.println(userid);
		DBConnection connectionDB = new DBConnection();
		PreparedStatement pstmt;

		Connection con = null;
		try {
			con = connectionDB.createConnection();
			pstmt = con.prepareStatement(SQL);
			pstmt.setString(1, Name);
			pstmt.setString(2, Mobile);
			pstmt.setString(3, Email);
			pstmt.setString(4, userid);
			pstmt.executeUpdate();
			con.close();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
