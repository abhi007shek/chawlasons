package com.crmsavvy.service;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

import com.crmsavvy.dto.CommentDTO;
import com.crmsavvy.dto.LeadDTO;
import com.crmsavvy.dto.UserContPersonDTO;
import com.crmsavvy.dto.UserDTO;
import com.crmsavvy.dto.UserStockDTO;
import com.mvc.util.DBConnection;

public class LeadService {
	public List<LeadDTO> getRelatedLead(int leadID, int sublead) {
		/*
		 * Table Name : Field DataType 4 iepf 10 city 14 contact_found 15
		 * country 16 cumulative_valuation 18 first_name 21 leadid 25 parentlead
		 * 26 responsible_person 29 status 30 sublead
		 */
		DBConnection connections = new DBConnection();
		Connection connection;
		List<LeadDTO> relatedLeadList = new ArrayList();

		try {
			connection = connections.createConnection();
			Statement statement = connection.createStatement();
			ResultSet resultSet = statement.executeQuery(
					"select id,leadid,sublead,responsible_person,city,country,iepf,cumulative_valuation,status,contact_found,first_name from leads where leadid = '"
							+ leadID + "'");
			List<UserDTO> allUsersList = new ArrayList();
			Map<String, String> userMAp = new HashMap<String, String>();
			System.out.println("UserService.allUsersList" + UserService.allUsersList.size());
			for (UserDTO user : UserService.allUsersList) {
				userMAp.put(user.getE_mail(), user.getName());
			}
			while (resultSet.next()) {
				if (resultSet.getInt(3) != sublead) {
					LeadDTO dto = new LeadDTO();
					dto.setId(resultSet.getString(1));
					dto.setLeadId(resultSet.getInt(2));
					dto.setSubLead(resultSet.getInt(3));
					dto.setResponsible_Person(userMAp.get(resultSet.getString(4)));
					dto.setCity(resultSet.getString(5));
					dto.setCountry(resultSet.getString(6));
					dto.setIEPF(resultSet.getString(7));
					dto.setCumulative_Valuation(resultSet.getString(8));
					dto.setStatus(resultSet.getString(9));
					dto.setContact_Found(resultSet.getString(10));
					dto.setFirst_Name(resultSet.getString(11));
					relatedLeadList.add(dto);
				}
			}
			System.out.println(relatedLeadList.size());
			resultSet.close();
			connection.close();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return relatedLeadList;
	}

	public LeadDTO getLead(String leadID) throws ClassNotFoundException, SQLException {
		DBConnection connections = new DBConnection();
		Connection connection = connections.createConnection();
		Statement statement = connection.createStatement();
		ResultSet resultSet = statement.executeQuery("select * from leads where id = '" + leadID + "' limit 1");
		List<UserDTO> allUsersList = new ArrayList();
		LeadDTO dto = new LeadDTO();
		Map<String, String> userMAp = new HashMap<String, String>();
		System.out.println("UserService.allUsersList" + UserService.allUsersList.size());
		for (UserDTO user : UserService.allUsersList) {
			userMAp.put(user.getE_mail(), user.getName());
		}
		while (resultSet.next()) {
			dto = new LeadDTO();
			dto.setId(resultSet.getString(1));
			dto.setAssginTo(resultSet.getString(9));
			dto.setAssignBy(resultSet.getString(10));
			dto.setResponsible_Person(userMAp.get(resultSet.getString(28)));
			dto.setFirst_Name(resultSet.getString(19));
			dto.setFather_hus_name(resultSet.getString(18));
			dto.setAddress(resultSet.getString(6));
			dto.setCity(resultSet.getString(11));
			dto.setCountry(resultSet.getString(16));
			dto.setPIN_Code(resultSet.getString(5));
			dto.setName_of_compny(resultSet.getString(24));
			dto.setNo_of_share(Integer.parseInt(resultSet.getString(26)));
			dto.setFOLIO_NUMBER(resultSet.getString(3));
			dto.setIEPF(resultSet.getString(4));
			dto.setCMP(resultSet.getString(2));
			dto.setValuation(Float.parseFloat(resultSet.getString(34)));
			dto.setType("listed");
			dto.setCumulative_Valuation(resultSet.getString(17));
			dto.setComments_by_RTA_if_any(resultSet.getString(12));
			dto.setStatus(resultSet.getString(31));
			dto.setLast_contacted_on(resultSet.getString(22));
			dto.setComments_by_person_responsible_for_contacting(resultSet.getString(14));
			dto.setNext_action_date(resultSet.getString(25));
			dto.setComments_by_finder_if_any(resultSet.getString(14));
			dto.setContact_Found(resultSet.getString(15));
			dto.setLeadId(resultSet.getInt(23));
			dto.setSubLead(resultSet.getInt(32));
			dto.setJointHolder(resultSet.getString(20));
			dto.setAllotmentDate(resultSet.getString(8));
			dto.setXsecond_joint_holder(resultSet.getString(35));
		}
		dto.setStocks(getStock(leadID));
		dto.setContPersons(getContInfo(leadID));
		dto.setCommentList(getCommentLead(leadID));
		System.out.println(dto.getContPersons().size());
		resultSet.close();
		connection.close();
		return dto;
	}

	public LeadDTO getLeadStatus(String leadID) throws ClassNotFoundException, SQLException {
		DBConnection connections = new DBConnection();
		Connection connection = connections.createConnection();
		Statement statement = connection.createStatement();
		ResultSet resultSet = statement.executeQuery("select * from leads where status = '" + leadID + "' limit 1");
		List<UserDTO> allUsersList = new ArrayList();
		LeadDTO dto = new LeadDTO();
		Map<String, String> userMAp = new HashMap<String, String>();
		System.out.println("UserService.allUsersList" + UserService.allUsersList.size());
		for (UserDTO user : UserService.allUsersList) {
			userMAp.put(user.getE_mail(), user.getName());
		}
		while (resultSet.next()) {
			dto.setId(resultSet.getString(1));
			dto.setAssginTo(resultSet.getString(9));
			dto.setAssignBy(resultSet.getString(10));
			dto.setResponsible_Person(userMAp.get(resultSet.getString(28)));
			dto.setFirst_Name(resultSet.getString(19));
			dto.setFather_hus_name(resultSet.getString(18));
			dto.setAddress(resultSet.getString(6));
			dto.setCity(resultSet.getString(11));
			dto.setCountry(resultSet.getString(16));
			dto.setPIN_Code(resultSet.getString(5));
			dto.setName_of_compny(resultSet.getString(24));
			dto.setNo_of_share(Integer.parseInt(resultSet.getString(26)));
			dto.setFOLIO_NUMBER(resultSet.getString(3));
			dto.setIEPF(resultSet.getString(4));
			dto.setCMP(resultSet.getString(2));
			dto.setValuation(Float.parseFloat(resultSet.getString(34)));
			dto.setType("listed");
			dto.setCumulative_Valuation(resultSet.getString(17));
			dto.setComments_by_RTA_if_any(resultSet.getString(12));
			dto.setStatus(resultSet.getString(31));
			dto.setLast_contacted_on(resultSet.getString(22));
			dto.setComments_by_person_responsible_for_contacting(resultSet.getString(14));
			dto.setNext_action_date(resultSet.getString(25));
			dto.setComments_by_finder_if_any(resultSet.getString(13));
			dto.setContact_Found(resultSet.getString(15));
			dto.setLeadId(resultSet.getInt(23));
			dto.setSubLead(resultSet.getInt(32));
		}
		resultSet.close();
		connection.close();
		return dto;
	}

	public Set<CommentDTO> getCommentLead(String leadId) throws ClassNotFoundException, SQLException {
		/*
		 * Printing connection object
		 * org.postgresql.jdbc4.Jdbc4Connection@26be92ad Table Name : Field
		 * DataType 1 id 2 comment 3 comment_date 4 email_of_person 5
		 * name_of_person 6 spoke_to 7 status 8 lead_id
		 * 
		 */
		DBConnection connections = new DBConnection();
		Connection connection = connections.createConnection();
		Statement statement = connection.createStatement();//
		ResultSet resultSet = statement.executeQuery("select * from CommentDTO where lead_id = '" + leadId + "' ORDER BY comment_date ASC");
		Set<CommentDTO> allComments = new HashSet<CommentDTO>();
		while (resultSet.next()) {
			CommentDTO contPersonDTO = new CommentDTO();
			contPersonDTO.setId(resultSet.getString(1));
			contPersonDTO.setComment(resultSet.getString(2));
			contPersonDTO.setComment_date(resultSet.getString(3));
			contPersonDTO.setEmail_of_person(resultSet.getString(4));
			contPersonDTO.setName_of_Person(resultSet.getString(5));
			contPersonDTO.setSpoke_To(resultSet.getString(6));
			contPersonDTO.setStatus(resultSet.getString(7));
			contPersonDTO.setContactNum_email(resultSet.getString(9));
			allComments.add(contPersonDTO);

		}
		resultSet.close();
		connection.close();
		return allComments;

	}

	public ArrayList<LeadDTO> searchLeads(String filter_type1, String filter_type2, String filter_type3,
			String filter_type4, String filter_value1, String filter_value2, String filter_value3, String filter_value4,
			String filter_logic1, String filter_logic2, String filter_logic3, UserDTO userDTO)
			throws ClassNotFoundException, SQLException {
		DBConnection connections = new DBConnection();
		Connection connection = connections.createConnection();
		Statement statement = connection.createStatement();
		ResultSet resultSet = null;
		/*
		 * SELECT * FROM Customers WHERE CustomerName ILIKE 'a%' AND Address
		 * ILIKE 'A%';
		 */

		if (filter_type1.length() > 0 && filter_value1.length() > 0) {
			System.out.println("1");
			if (userDTO.getRole().equals("Admin")) {
				resultSet = statement
						.executeQuery("select * from leads where " + filter_type1 + " ILIKE '%" + filter_value1 + "%'");

			} else {
				resultSet = statement.executeQuery("select * from leads where " + filter_type1 + " ILIKE '%"
						+ filter_value1 + "%'  AND " + " responsible_person = '" + userDTO.getUser_name() + "'");

			}
		}
		if ((filter_type1.length() > 0 && filter_value1.length() > 0)
				&& (filter_type2.length() > 0 && filter_value2.length() > 0)) {
			if (userDTO.getRole().equals("Admin")) {
				resultSet = statement
						.executeQuery("select * from leads where " + filter_type1 + " ILIKE '%" + filter_value1 + "%' "
								+ filter_logic1 + " " + filter_type2 + " ILIKE  '%" + filter_value2 + "%'");

			} else {
				resultSet = statement.executeQuery("select * from leads where " + filter_type1 + " ILIKE '%"
						+ filter_value1 + "%' " + filter_logic1 + " " + filter_type2 + " ILIKE  '%" + filter_value2
						+ "%' AND " + " responsible_person = '" + userDTO.getUser_name() + "'");

			}

			System.out.println("2");
		}

		if ((filter_type1.length() > 0 && filter_value1.length() > 0)
				&& (filter_type2.length() > 0 && filter_value2.length() > 0)
				&& (filter_type3.length() > 0 && filter_value3.length() > 0)) {
			if (userDTO.getRole().equals("Admin")) {
				resultSet = statement.executeQuery("select * from leads where " + filter_type1 + " ILIKE  '%"
						+ filter_value1 + "%' " + filter_logic1 + " " + filter_type2 + " ILIKE  '%" + filter_value2
						+ "%' " + filter_logic2 + " " + filter_type3 + " ILIKE  '%" + filter_value3 + "%'");

			} else {
				resultSet = statement.executeQuery("select * from leads where " + filter_type1 + " ILIKE  '%"
						+ filter_value1 + "%' " + filter_logic1 + " " + filter_type2 + " ILIKE  '%" + filter_value2
						+ "%' " + filter_logic2 + " " + filter_type3 + " ILIKE  '%" + filter_value3 + "%' AND "
						+ " responsible_person = '" + userDTO.getUser_name() + "'");

			}

			System.out.println("3");
		}
		if ((filter_type1.length() > 0 && filter_value1.length() > 0)
				&& (filter_type2.length() > 0 && filter_value2.length() > 0)
				&& (filter_type3.length() > 0 && filter_value3.length() > 0)
				&& (filter_type4.length() > 0 && filter_value4.length() > 0)) {
			if (userDTO.getRole().equals("Admin")) {
				resultSet = statement.executeQuery("select * from leads where " + filter_type1 + " ILIKE '%"
						+ filter_value1 + "%' " + filter_logic1 + " " + filter_type2 + " ILIKE  '%" + filter_value2
						+ "%'" + " " + filter_logic2 + " " + filter_type3 + " ILIKE  '%" + filter_value3 + "%'" + " "
						+ filter_logic3 + " " + filter_type4 + " ILIKE  '%" + filter_value4 + "%'");

			} else {
				resultSet = statement.executeQuery("select * from leads where " + filter_type1 + " ILIKE '%"
						+ filter_value1 + "%' " + filter_logic1 + " " + filter_type2 + " ILIKE  '%" + filter_value2
						+ "%'" + " " + filter_logic2 + " " + filter_type3 + " ILIKE  '%" + filter_value3 + "%'" + " "
						+ filter_logic3 + " " + filter_type4 + " ILIKE  '%" + filter_value4 + "%' AND "
						+ " responsible_person = '" + userDTO.getUser_name() + "'");

			}

			System.out.println("4");
		}

		System.out.println("searching");
		LeadDTO dto = new LeadDTO();
		ArrayList<LeadDTO> leadDTOs = new ArrayList<LeadDTO>();
		Map<String, String> userMAp = new HashMap<String, String>();
		System.out.println("UserService.allUsersList" + UserService.allUsersList.size());
		for (UserDTO user : UserService.allUsersList) {
			userMAp.put(user.getE_mail(), user.getName());
		}
		while (resultSet.next()) {
			dto = new LeadDTO();
			dto.setId(resultSet.getString(1));
			dto.setAssginTo(resultSet.getString(9));
			dto.setAssignBy(resultSet.getString(10));
			dto.setResponsible_Person(userMAp.get(resultSet.getString(28)));
			dto.setFirst_Name(resultSet.getString(19));
			dto.setFather_hus_name(resultSet.getString(18));
			dto.setAddress(resultSet.getString(6));
			dto.setCity(resultSet.getString(11));
			dto.setCountry(resultSet.getString(16));
			dto.setPIN_Code(resultSet.getString(5));
			dto.setName_of_compny(resultSet.getString(24));
			dto.setNo_of_share(Integer.parseInt(resultSet.getString(26)));
			dto.setFOLIO_NUMBER(resultSet.getString(3));
			dto.setIEPF(resultSet.getString(4));
			dto.setCMP(resultSet.getString(2));
			dto.setValuation(Float.parseFloat(resultSet.getString(34)));
			dto.setType("listed");
			
			dto.setCumulative_Valuation(resultSet.getString(17));
			dto.setComments_by_RTA_if_any(resultSet.getString(12));
			dto.setStatus(resultSet.getString(31));
			dto.setLast_contacted_on(resultSet.getString(22));
			dto.setComments_by_person_responsible_for_contacting(resultSet.getString(14));
			dto.setNext_action_date(resultSet.getString(25));
			dto.setComments_by_finder_if_any(resultSet.getString(13));
			dto.setContact_Found(resultSet.getString(15));
			dto.setLeadId(resultSet.getInt(23));
			dto.setSubLead(resultSet.getInt(32));
			leadDTOs.add(dto);

		}
		resultSet.close();
		connection.close();
		return leadDTOs;
	}

	public Set<UserStockDTO> getStock(String leadId) throws ClassNotFoundException, SQLException {
		DBConnection connections = new DBConnection();
		Connection connection = connections.createConnection();
		Statement statement = connection.createStatement();//
		ResultSet resultSet = statement.executeQuery("select * from userStock where lead_id = '" + leadId + "'");
		Set<UserStockDTO> allUsersList = new HashSet<UserStockDTO>();
		while (resultSet.next()) {
			/**
			 * 1 id 2 cmp 3 count 4 folionum 5 leadid 6 mention_if_in_iepf 7
			 * name 8 no_of_stocks 9 price 10 tadressaspercompany 11 valuation
			 * 12 lead_id
			 */
			UserStockDTO dto2 = new UserStockDTO();

			System.out.println("-------------------------");
			System.out.println(resultSet.getString(1));
			dto2.setID(resultSet.getString(1));
			dto2.setCMP(Float.parseFloat(resultSet.getString(2)));
			dto2.setCount(Integer.parseInt(resultSet.getString(3)));
			dto2.setFolioNum(resultSet.getString(4));
			dto2.setMention_if_in_IEPF(resultSet.getString(6));
			dto2.setName(resultSet.getString(7));
			dto2.setNo_of_stocks(Integer.parseInt(resultSet.getString(8)));
			dto2.setPrice(Float.parseFloat(resultSet.getString(9)));
			dto2.setValuation(Float.parseFloat(resultSet.getString(11)));
			dto2.settAdressAsperCompany(resultSet.getString(10));
			System.out.println("-------------------------");
			allUsersList.add(dto2);
		}
		resultSet.close();
		connection.close();
		return allUsersList;
	}

	public Set<UserContPersonDTO> getContInfo(String leadId) throws ClassNotFoundException, SQLException {
		DBConnection connections = new DBConnection();
		Connection connection = connections.createConnection();
		Statement statement = connection.createStatement();//
		ResultSet resultSet = statement.executeQuery("select * from user_contact where lead_id = '" + leadId + "'");
		Set<UserContPersonDTO> allUsersList = new HashSet<UserContPersonDTO>();
		while (resultSet.next()) {
			UserContPersonDTO contPersonDTO = new UserContPersonDTO();
			System.out.println("-----------resultSet.getString(5)--------------");
			System.out.println(resultSet.getString(5));
			// contPersonDTO.set
			/*
			 * 1 id 2 address 3 address_source 4 contact_no 5 contact_person 6
			 * contact_source 7 email_id 8 lead_id
			 */
			contPersonDTO.setID(resultSet.getString(1));
			contPersonDTO.setADDRESS(resultSet.getString(2));
			contPersonDTO.setADDRESS_SOURCE("NA");
			contPersonDTO.setCONTACT_NO(resultSet.getString(4));
			contPersonDTO.setCONTACT_PERSON(resultSet.getString(5));
			contPersonDTO.setCONTACT_SOURCE(resultSet.getString(6));
			contPersonDTO.setEMAIL_ID(resultSet.getString(7));
			contPersonDTO.setActive(resultSet.getBoolean(8));
			allUsersList.add(contPersonDTO);
			System.out.println("-------------------------");

		}
		resultSet.close();
		connection.close();
		return allUsersList;
	}

	public void updateLead(String leadID, LeadDTO reqDto, CommentDTO commentDTO, String contpersonID) {
		SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
		LeadDTO dto = new LeadDTO();
		Session session = sessionFactory.openSession();// openSession();
		Transaction tx = session.beginTransaction();
		dto = (LeadDTO) session.load("com.crmsavvy.dto.LeadDTO", leadID);
		if (reqDto.getComments_by_finder_if_any() != null && reqDto.getComments_by_RTA_if_any() != null) {
			dto.setComments_by_finder_if_any(reqDto.getComments_by_finder_if_any());
			dto.setComments_by_RTA_if_any(reqDto.getComments_by_RTA_if_any());
		} else {
			dto.setStatus(reqDto.getStatus());
			if (reqDto.getResponsible_Person() == null) {

			} else {
				dto.setResponsible_Person(reqDto.getResponsible_Person());
				dto.setAssginTo(reqDto.getAssginTo());
				dto.setAssignBy(reqDto.getAssignBy());
			}
			/*
			 * dto.setComments_by_person_responsible_for_contacting(
			 * reqDto.getComments_by_person_responsible_for_contacting());
			 */

			dto.setLast_contacted_on(reqDto.getLast_contacted_on());
			dto.setComments_by_person_responsible_for_contacting(
					reqDto.getComments_by_person_responsible_for_contacting());
			dto.setNext_action_date(reqDto.getNext_action_date());
			if (dto.getStatus().equals("CONTACTED-WRONG NUMBER")
					|| dto.getStatus().equals("CONTACTED-INACTIVE NUMBER")) {
				System.out.println("contpersonID " + contpersonID);
				if (contpersonID != "Select Contact") {

					Set<UserContPersonDTO> commentDTOs = dto.getContPersons();
					System.out.println(commentDTOs.size());
					for (UserContPersonDTO contperson : commentDTOs) {
						if (contperson.getID().equals(contpersonID)) {
							System.out.println("contPersonTOinactive - " + contpersonID);
							contperson.setActive(false);
						}
					}
				}
			} else {
				if (contpersonID != "Select Contact") {
					Set<UserContPersonDTO> commentDTOs = dto.getContPersons();
					System.out.println(commentDTOs.size());
					for (UserContPersonDTO contperson : commentDTOs) {
						if (contperson.getID().equals(contpersonID)) {
							commentDTO.setEmail_of_person(contperson.getCONTACT_PERSON());
						}
					}
				}

			}

		}

		if (commentDTO != null) {
			Set<CommentDTO> commentDTOs = dto.getCommentList();
			commentDTO.setDto(dto);
			commentDTOs.add(commentDTO);
		}
		session.update(dto);
		tx.commit();
		session.close();

	}

	public ArrayList<LeadDTO> loadWrongCont() {
		ArrayList<LeadDTO> leadDTOs = new ArrayList<LeadDTO>();
		Configuration configuration = new Configuration().configure();
		ServiceRegistryBuilder registry = new ServiceRegistryBuilder();
		registry.applySettings(configuration.getProperties());
		ServiceRegistry serviceRegistry = registry.buildServiceRegistry();
		// builds a session factory from the service registry
		SessionFactory sessionFactory = configuration.buildSessionFactory(serviceRegistry);
		boolean status = false;
		// obtains the session
		Session session = sessionFactory.openSession();// openSession();
		session.beginTransaction();

		// EAGER FETCHING WITH list()
		System.out.println("Printing with list()");
		Query q = session.createQuery(
				"FROM com.crmsavvy.dto.LeadDTO where status='CONTACTED-WRONG NUMBER' OR status='CONTACTED-INACTIVE NUMBER' ");
		
		/*Query q = session.createQuery(
				"FROM com.crmsavvy.dto.LeadDTO");*/
	
		List<LeadDTO> userStockDTOs = q.list();

		for (LeadDTO dto : userStockDTOs) {
			int inactiveCount = dto.getContPersons().size();
			int i = 0;
			for (UserContPersonDTO contPersonDTO : dto.getContPersons()) {
				if (!contPersonDTO.isActive()) {
					i++;

				}
			}
			if (inactiveCount == i) {
				leadDTOs.add(dto);
				session.delete(dto);

			}
		}
		session.getTransaction().commit();
		session.close();
		// deleteWrong();
		return leadDTOs;
	}

	public void deleteWrong() {

	}

	public Set<LeadDTO> loadLeadCalander(UserDTO userDTO) {
		DBConnection connections = new DBConnection();
		Connection connection;
		Set<LeadDTO> leadDTOs = new HashSet<LeadDTO>();
		try {
			connection = connections.createConnection();
			Statement statement = connection.createStatement();// where
																// responsible_person=
																// 'padu@gmail.com'
			ResultSet resultSet = null;
			if (userDTO.getRole().equals("Admin")) {
				resultSet = statement
						.executeQuery("select id,first_name,next_action_date,status,responsible_person from leads");

			} else {
				resultSet = statement.executeQuery(
						"select id,first_name,next_action_date,status,responsible_person from leads where responsible_person = '"
								+ userDTO.getUser_name() + "'");

			}
			while (resultSet.next()) {
				LeadDTO leadDTO = new LeadDTO();
				leadDTO.setId(resultSet.getString(1));
				leadDTO.setFirst_Name(resultSet.getString(2).replaceAll("[^a-zA-Z]+", ""));
				leadDTO.setNext_action_date(resultSet.getString(3));
				leadDTO.setStatus(resultSet.getString(4));
				leadDTO.setResponsible_Person(resultSet.getString(5));
				leadDTOs.add(leadDTO);
			}
			System.out.println(leadDTOs.size());

			connection.close();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return leadDTOs;
	}

	public String deleteLead(String leadId, int maxID) {
		Configuration configuration = new Configuration().configure();
		ServiceRegistryBuilder registry = new ServiceRegistryBuilder();
		registry.applySettings(configuration.getProperties());
		ServiceRegistry serviceRegistry = registry.buildServiceRegistry();
		// builds a session factory from the service registry
		SessionFactory sessionFactory = configuration.buildSessionFactory(serviceRegistry);

		// obtains the session
		Session session = sessionFactory.openSession();// openSession();
		session.beginTransaction();

		// EAGER FETCHING WITH list()
		System.out.println("Printing with list()");
		Query q = session.createQuery("FROM com.crmsavvy.dto.LeadDTO where id='" + leadId + "'");
		LeadDTO dtoTemp = new LeadDTO();
		List<LeadDTO> userStockDTOs = q.list();
		for (LeadDTO dto : userStockDTOs) {
			dtoTemp = dto;
			maxID = maxID + 1;

			dto.setLeadId(maxID);
			dto.setSubLead(0);
			session.update(dto);
			dtoTemp.setLeadId(maxID);
		}
		System.out.println("ID - " + dtoTemp.getId());
		session.getTransaction().commit();
		session.close();
		return dtoTemp.getId();
	}

	public void createNewRelatedLead(String parentLead, String sublead, String MasterLead, String maxSublead) {
		Configuration configuration = new Configuration().configure();
		ServiceRegistryBuilder registry = new ServiceRegistryBuilder();
		registry.applySettings(configuration.getProperties());
		ServiceRegistry serviceRegistry = registry.buildServiceRegistry();
		SessionFactory sessionFactory = configuration.buildSessionFactory(serviceRegistry);

		// obtains the session
		Session session = sessionFactory.openSession();// openSession();
		Query q;
		session.beginTransaction();
		if (sublead.isEmpty()) {
			q = session.createQuery("FROM com.crmsavvy.dto.LeadDTO where leadid='" + parentLead + "'");

		} else {
			q = session.createQuery(
					"FROM com.crmsavvy.dto.LeadDTO where leadid='" + parentLead + "' AND sublead='" + sublead + "'");
		}

		int nextSublead = Integer.parseInt(maxSublead);
		nextSublead++;
		LeadDTO dtoTemp = new LeadDTO();
		List<LeadDTO> userStockDTOs = q.list();
		for (LeadDTO dto : userStockDTOs) {
			dtoTemp = dto;

			dto.setLeadId(Integer.parseInt(MasterLead));
			dto.setSubLead(nextSublead);
			session.update(dto);
		}
		session.getTransaction().commit();
		session.close();

	}

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		LeadService leadService = new LeadService();
		leadService.getRelatedLead(5086, 2);
	}

}
