package com.crmsavvy.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

import com.crmsavvy.dto.LeadDTO;
import com.crmsavvy.dto.ParentStockDTO;
import com.crmsavvy.dto.UserStockDTO;
import com.mvc.util.DBConnection;

public class StockService {
	public void updateStock(List<ParentStockDTO> parntDTOlst) throws ClassNotFoundException, SQLException {
		Configuration configuration = new Configuration().configure();
		ServiceRegistryBuilder registry = new ServiceRegistryBuilder();
		registry.applySettings(configuration.getProperties());
		ServiceRegistry serviceRegistry = registry.buildServiceRegistry();

		Map<String, ParentStockDTO> ParentStockDTOMap = new HashMap<String, ParentStockDTO>();
		for (ParentStockDTO stock : parntDTOlst) {
			ParentStockDTOMap.put(stock.getSymbol(), stock);
		}
		// builds a session factory from the service registry
		SessionFactory sessionFactory = configuration.buildSessionFactory(serviceRegistry);

		// obtains the session
		Session session = sessionFactory.openSession();// openSession();
		session.beginTransaction();

		// EAGER FETCHING WITH list()
		System.out.println("Printing with list()");
		Query q = session.createQuery("FROM com.crmsavvy.dto.UserStockDTO");
		List<UserStockDTO> userStockDTOs = q.list();
		for (UserStockDTO dto : userStockDTOs) {
			dto.setCMP(ParentStockDTOMap.get(dto.getName()).getClose());
			dto.setValuation(dto.getCMP() * dto.getNo_of_stocks());// *
																	// dto.getNo_of_stocks()
			session.update(dto);
		}
		session.getTransaction().commit();
		session.close();
	}

	public void createStock(String leadID, UserStockDTO stockDTO) throws ClassNotFoundException, SQLException {
		Configuration configuration = new Configuration().configure();
		ServiceRegistryBuilder registry = new ServiceRegistryBuilder();
		registry.applySettings(configuration.getProperties());
		ServiceRegistry serviceRegistry = registry.buildServiceRegistry();
		SessionFactory sessionFactory = configuration.buildSessionFactory(serviceRegistry);
		LeadDTO dto = new LeadDTO();

		Session session = sessionFactory.openSession();// openSession();
		session.beginTransaction();

		System.out.println("--");
		dto = (LeadDTO) session.load("com.crmsavvy.dto.LeadDTO", leadID);
		float cumVal = 0;
		dto.getStocks().add(stockDTO);
		for (UserStockDTO stockDTO2 : dto.getStocks()) {
			cumVal = cumVal + stockDTO2.getValuation();
		}
		dto.setCumulative_Valuation(cumVal + "");
		stockDTO.setDto(dto);
		
		System.out.println(dto.getStocks().size());
		session.update(dto);
		// session.save(stockDTO);
		session.getTransaction().commit();
		System.out.println("saved");
		session.close();
	}

	public ParentStockDTO getParentStock(String symbol) {
		Connection connection;
		ParentStockDTO parentStockDTO = new ParentStockDTO();

		try {
			connection = DBConnection.createConnection();
			Statement statement = connection.createStatement();
			ResultSet resultSet = statement.executeQuery("select * from parentStock where symbol = '" + symbol + "'");
			while (resultSet.next()) {

				parentStockDTO.setSymbol(resultSet.getString(1));
				parentStockDTO.setClose(Float.parseFloat(resultSet.getString(2)));
			}

			connection.close();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return parentStockDTO;
	}

	public void updateStock(String stock_id, String Stock_Name, String IEPF, String Address, String no_of_stock,
			float valuation, float price) {
		DBConnection connections = new DBConnection();
		Connection connection;
		try {
			connection = connections.createConnection();

			PreparedStatement preparedStatement = connection.prepareStatement(
					"UPDATE userStock SET cmp=?,no_of_stocks=?,valuation=?,mention_if_in_iepf=?,name=?  WHERE id = ?");
			preparedStatement.setFloat(1, price);
			preparedStatement.setInt(2, Integer.parseInt(no_of_stock));
			preparedStatement.setFloat(3, valuation);
			preparedStatement.setString(4, IEPF);
			preparedStatement.setString(5, Stock_Name);
			preparedStatement.setString(6, stock_id);
			preparedStatement.executeUpdate();
			preparedStatement.close();
			connection.close();

		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		/*
		 * 1 id 2 cmp 3 count 4 folionum 5 leadid 6 mention_if_in_iepf 7 name 8
		 * no_of_stocks 9 price 10 tadressaspercompany 11 valuation 12 lead_id
		 */
	}
	public static void main(String[] args) {
		StockService service = new StockService();
//		service.searchStock();
		//ParentStockDTO parentStockDTO = service.getParentStock("500002");
		//System.out.println(parentStockDTO.getClose());
		// service.getParentStock("500002");
	}

}
