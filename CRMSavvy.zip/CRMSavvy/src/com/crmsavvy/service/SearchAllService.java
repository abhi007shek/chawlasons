package com.crmsavvy.service;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

import com.crmsavvy.dto.LeadDTO;
import com.crmsavvy.dto.UserDTO;
import com.crmsavvy.dto.UserStockDTO;

public class SearchAllService {

	public void globalSearch(String Keyword) {

		String SQLlead = "";
		String SQLStock = "";
		String SQLContact = "";
		String SQLBhav = "";
		String SQLUser = "";

	}

	public ArrayList<LeadDTO> searchStock(String filter_type1, String filter_type2, String filter_type3,
			String filter_type4, String filter_value1, String filter_value2, String filter_value3, String filter_value4,
			String filter_logic1, String filter_logic2, String filter_logic3, UserDTO userDTO) {
		Configuration configuration = new Configuration().configure();
		ServiceRegistryBuilder registry = new ServiceRegistryBuilder();
		registry.applySettings(configuration.getProperties());
		ServiceRegistry serviceRegistry = registry.buildServiceRegistry();
		ArrayList<LeadDTO> leadDTOs = new ArrayList<LeadDTO>();
		// builds a session factory from the service registry
		SessionFactory sessionFactory = configuration.buildSessionFactory(serviceRegistry);

		// obtains the session
		Session session = sessionFactory.openSession();// openSession();
		session.beginTransaction();

		// EAGER FETCHING WITH list()
		System.out.println("Printing with list()");
		String sql = "FROM com.crmsavvy.dto.UserStockDTO where CAST(";
		if (filter_type1.length() > 0 && filter_value1.length() > 0) {
			System.out.println("1");

			if (userDTO.getRole().equals("Admin")) {
				sql = sql + filter_type1 + " AS text) LIKE '%" + filter_value1 + "%'";

			} else {
				sql = sql + filter_type1 + " AS text) LIKE '%" + filter_value1 + "%'  AND " + " responsible_person = '"
						+ userDTO.getUser_name() + "'";

			}
		}
		if ((filter_type1.length() > 0 && filter_value1.length() > 0)
				&& (filter_type2.length() > 0 && filter_value2.length() > 0)) {
			if (userDTO.getRole().equals("Admin")) {
				sql = sql + filter_type1 + " AS text) LIKE '%" + filter_value1 + "%' " + filter_logic1 + " CAST(" + filter_type2
						+ " AS text) LIKE  '%" + filter_value2 + "%'";

			} else {
				sql = sql + filter_type1 + " AS text) LIKE '%" + filter_value1 + "%' " + filter_logic1 + " CAST(" + filter_type2
						+ " AS text) LIKE  '%" + filter_value2 + "%' AND " + " responsible_person = '" + userDTO.getUser_name()
						+ "'";

			}

			System.out.println("2");
		}

		if ((filter_type1.length() > 0 && filter_value1.length() > 0)
				&& (filter_type2.length() > 0 && filter_value2.length() > 0)
				&& (filter_type3.length() > 0 && filter_value3.length() > 0)) {
			if (userDTO.getRole().equals("Admin")) {
				sql = sql + filter_type1 + " AS text) LIKE  '%" + filter_value1 + "%' " + filter_logic1 + " CAST(" + filter_type2
						+ " AS text) LIKE  '%" + filter_value2 + "%' " + filter_logic2 + " CAST(" + filter_type3 + " AS text) LIKE  '%"
						+ filter_value3 + "%'";

			} else {
				sql = sql + filter_type1 + " AS text) LIKE '%" + filter_value1 + "%' " + filter_logic1 + " CAST(" + filter_type2
						+ " AS text) LIKE  '%" + filter_value2 + "%' " + filter_logic2 + " CAST(" + filter_type3 + " AS text) LIKE  '%"
						+ filter_value3 + "%' AND " + " responsible_person = '" + userDTO.getUser_name() + "'";

			}

			System.out.println("3");
		}
		if ((filter_type1.length() > 0 && filter_value1.length() > 0)
				&& (filter_type2.length() > 0 && filter_value2.length() > 0)
				&& (filter_type3.length() > 0 && filter_value3.length() > 0)
				&& (filter_type4.length() > 0 && filter_value4.length() > 0)) {
			if (userDTO.getRole().equals("Admin")) {
				sql = sql + filter_type1 + "AS text)  LIKE '%" + filter_value1 + "%' " + filter_logic1 + " CAST(" + filter_type2
						+ " AS text) LIKE  '%" + filter_value2 + "%'" + " " + filter_logic2 + "  CAST(" + filter_type3 + " AS text) LIKE  '%"
						+ filter_value3 + "%'" + " " + filter_logic3 + " CAST(" + filter_type4 + " AS text) LIKE  '%" + filter_value4
						+ "%'";

			} else {
				sql = sql + filter_type1 + " AS text) LIKE '%" + filter_value1 + "%' " + filter_logic1 + " CAST(" + filter_type2
						+ " AS text) LIKE  '%" + filter_value2 + "%'" + " " + filter_logic2 + " CAST(" + filter_type3 + " AS text) LIKE  '%"
						+ filter_value3 + "%'" + " " + filter_logic3 + " CAST(" + filter_type4 + " AS text) LIKE  '%" + filter_value4
						+ "%' AND " + " responsible_person = '" + userDTO.getUser_name() + "'";

			}

			System.out.println("4");
		}

		Query q = session.createQuery(sql);
		List<UserStockDTO> userStockDTOs = q.list();
		for (UserStockDTO dto : userStockDTOs) {
			leadDTOs.add(dto.getDto());
		}
		session.getTransaction().commit();
		session.close();

		return leadDTOs;
	}

	public ArrayList<LeadDTO> searchContact(String filter_type1, String filter_type2, String filter_type3,
			String filter_type4, String filter_value1, String filter_value2, String filter_value3, String filter_value4,
			String filter_logic1, String filter_logic2, String filter_logic3, UserDTO userDTO) {
		Configuration configuration = new Configuration().configure();
		ServiceRegistryBuilder registry = new ServiceRegistryBuilder();
		registry.applySettings(configuration.getProperties());
		ServiceRegistry serviceRegistry = registry.buildServiceRegistry();
		ArrayList<LeadDTO> leadDTOs = new ArrayList<LeadDTO>();
		// builds a session factory from the service registry
		SessionFactory sessionFactory = configuration.buildSessionFactory(serviceRegistry);

		// obtains the session
		Session session = sessionFactory.openSession();// openSession();
		session.beginTransaction();

		// EAGER FETCHING WITH list()
		System.out.println("Printing with list()");
		String sql = "FROM com.crmsavvy.dto.UserContPersonDTO  where CAST(";
		if (filter_type1.length() > 0 && filter_value1.length() > 0) {
			System.out.println("1");

			if (userDTO.getRole().equals("Admin")) {
				sql = sql + filter_type1 + " AS text) LIKE '%" + filter_value1 + "%'";

			} else {
				sql = sql + filter_type1 + " AS text) LIKE '%" + filter_value1 + "%'  AND " + " responsible_person = '"
						+ userDTO.getUser_name() + "'";

			}
		}
		if ((filter_type1.length() > 0 && filter_value1.length() > 0)
				&& (filter_type2.length() > 0 && filter_value2.length() > 0)) {
			if (userDTO.getRole().equals("Admin")) {
				sql = sql + filter_type1 + " AS text) LIKE '%" + filter_value1 + "%' " + filter_logic1 + "  CAST(" + filter_type2
						+ " AS text) LIKE  '%" + filter_value2 + "%'";

			} else {
				sql = sql + filter_type1 + " LIKE '%" + filter_value1 + "%' " + filter_logic1 + "  CAST(" + filter_type2
						+ " AS text) LIKE  '%" + filter_value2 + "%' AND " + " responsible_person = '" + userDTO.getUser_name()
						+ "'";

			}

			System.out.println("2");
		}

		if ((filter_type1.length() > 0 && filter_value1.length() > 0)
				&& (filter_type2.length() > 0 && filter_value2.length() > 0)
				&& (filter_type3.length() > 0 && filter_value3.length() > 0)) {
			if (userDTO.getRole().equals("Admin")) {
				sql = sql + filter_type1 + " AS text) LIKE  '%" + filter_value1 + "%' " + filter_logic1 + "  CAST(" + filter_type2
						+ " AS text) LIKE  '%" + filter_value2 + "%' " + filter_logic2 + " CAST(" + filter_type3 + " AS text) LIKE  '%"
						+ filter_value3 + "%'";

			} else {
				sql = sql + filter_type1 + " AS text) LIKE  '%" + filter_value1 + "%' " + filter_logic1 + "  CAST(" + filter_type2
						+ " AS text) LIKE  '%" + filter_value2 + "%' " + filter_logic2 + " CAST(" + filter_type3 + " AS text) LIKE  '%"
						+ filter_value3 + "%' AND " + " responsible_person = '" + userDTO.getUser_name() + "'";

			}

			System.out.println("3");
		}
		if ((filter_type1.length() > 0 && filter_value1.length() > 0)
				&& (filter_type2.length() > 0 && filter_value2.length() > 0)
				&& (filter_type3.length() > 0 && filter_value3.length() > 0)
				&& (filter_type4.length() > 0 && filter_value4.length() > 0)) {
			if (userDTO.getRole().equals("Admin")) {
				sql = sql + filter_type1 + " AS text) LIKE '%" + filter_value1 + "%' " + filter_logic1 + "  CAST(" + filter_type2
						+ " AS text) LIKE  '%" + filter_value2 + "%'" + " " + filter_logic2 + "  CAST(" + filter_type3 + " AS text) LIKE  '%"
						+ filter_value3 + "%'" + " " + filter_logic3 + " CAST(" + filter_type4 + " AS text) LIKE  '%" + filter_value4
						+ "%'";

			} else {
				sql = sql + filter_type1 + " AS text) LIKE '%" + filter_value1 + "%' " + filter_logic1 + "  CAST(" + filter_type2
						+ " AS text) LIKE  '%" + filter_value2 + "%'" + " " + filter_logic2 + "  CAST(" + filter_type3 + " AS text) LIKE  '%"
						+ filter_value3 + "%'" + " " + filter_logic3 + " CAST(" + filter_type4 + " AS text) LIKE  '%" + filter_value4
						+ "%' AND " + " responsible_person = '" + userDTO.getUser_name() + "'";

			}

			System.out.println("4");
		}

		Query q = session.createQuery(sql);

		List<UserStockDTO> userStockDTOs = q.list();
		for (UserStockDTO dto : userStockDTOs) {
			leadDTOs.add(dto.getDto());
		}
		session.getTransaction().commit();
		session.close();
		return leadDTOs;
	}

	public static void main(String[] args) {

	}
}
