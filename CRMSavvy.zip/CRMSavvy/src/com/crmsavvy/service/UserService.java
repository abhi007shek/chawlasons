package com.crmsavvy.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.catalina.User;
import org.eclipse.jdt.internal.compiler.ast.ArrayAllocationExpression;

import com.crmsavvy.dto.UserDTO;
import com.mvc.util.DBConnection;

public class UserService {
	public static List<UserDTO> allUsersList = new ArrayList();

	public UserService() {
		try {
			allUsersList = getAllUsers();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void createUser(UserDTO userDTO) throws ClassNotFoundException {
		System.out.println("Creating user.......");
		DBConnection connections = new DBConnection();
		Connection connection = null;
		try {
			connection = connections.createConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String SQL = "INSERT INTO users(user_name,password,name,role,e_mail,totalLead,openLead,closeLead,isactive,stocktype) VALUES (?,?,?,?,?,?,?,?,?,?)";
		PreparedStatement preparedStatement = null;
		try {
			preparedStatement = connection.prepareStatement(SQL);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			preparedStatement.setString(1, userDTO.getUser_name());
			preparedStatement.setString(2, userDTO.getPassword());
			preparedStatement.setString(3, userDTO.getName());
			preparedStatement.setString(4, userDTO.getRole());
			preparedStatement.setString(5, userDTO.getE_mail());
			preparedStatement.setInt(6, userDTO.getTotalLead());
			preparedStatement.setInt(7, userDTO.getOpenLead());
			preparedStatement.setInt(8, userDTO.getCloseLead());
			preparedStatement.setString(9, "true");
			preparedStatement.setString(10, userDTO.getStocktype());
			preparedStatement.executeUpdate();
			preparedStatement.close();
			connection.close();
			getAllUsers();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public List<UserDTO> getAllUsers() throws ClassNotFoundException, SQLException {
		DBConnection connections = new DBConnection();
		Connection connection = connections.createConnection();
		Statement statement = connection.createStatement();
		ResultSet resultSet = statement.executeQuery("select * from users");
		UserService.allUsersList = new ArrayList();
		while (resultSet.next()) {
			UserDTO dto = new UserDTO();
			dto.setId(resultSet.getString(1));
			dto.setName(resultSet.getString(2));
			dto.setRole(resultSet.getString(3));
			dto.setTotalLead(resultSet.getInt(7));
			dto.setE_mail(resultSet.getString(4));
			dto.setOpenLead(resultSet.getInt(8));
			dto.setCloseLead(resultSet.getInt(9));
			dto.setIsactive(resultSet.getBoolean(10));
			dto.setStocktype(resultSet.getString(11));
			UserService.allUsersList.add(dto);
		}
		resultSet.close();
		statement.close();
		connection.close();
		return allUsersList;

	}

	/*
	 * 1 id 2 name 3 role 4 user_name 5 password 6 e_mail 7 totallead 8 openlead
	 * 9 closelead 10 isactive 11 stocktype
	 */
	public void deleteUser(String userID) {
		DBConnection connections = new DBConnection();
		Connection connection;
		try {
			connection = connections.createConnection();
			Statement statement = connection.createStatement();
			statement.executeUpdate("UPDATE users SET isactive = 'false' WHERE e_mail = '" + userID + "'");
			statement.close();
			getAllUsers();

		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void editUser(String userID, String Name, String role, String stockType, String email) {
		DBConnection connections = new DBConnection();
		Connection connection;
		try {
			connection = connections.createConnection();

			PreparedStatement preparedStatement = connection
					.prepareStatement("UPDATE users SET name=?,role=?,stocktype=?  WHERE id = ?");
			preparedStatement.setString(1, Name);
			preparedStatement.setString(2, role);
			preparedStatement.setString(3, stockType);
			preparedStatement.setInt(4, Integer.parseInt(userID));
			preparedStatement.executeUpdate();
			preparedStatement.close();
			connection.close();
			getAllUsers();

		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public boolean checkDuplicateUser(String Email) {
		// UserService.allUsersList;
		System.out.println("Checking duplicate ");
		DBConnection connections = new DBConnection();
		Connection connection;
		try {
			connection = connections.createConnection();
			Statement statement = connection.createStatement();
			ResultSet resultSet = statement.executeQuery("select user_name from users WHERE user_name = '" + Email + "'");
			
			if (resultSet.next()) {
				System.out.println("Duplicate found");
				connection.close();
				statement.close();
				
				return true;

			} else {
				System.out.println("Duplicate Not found");
				connection.close();
				statement.close();
				return false;

			}

		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;

	}

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		UserService service = new UserService();
		service.getAllUsers();
	}

}
