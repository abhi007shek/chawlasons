package com.crmsavvy.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.crmsavvy.dto.UserDTO;
import com.mvc.util.DBConnection;

import java.net.URI;
import java.net.URI;
import java.net.URISyntaxException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class LoginService {
	public static UserDTO dto = null;

	public UserDTO login(String email, String pass) throws URISyntaxException, ClassNotFoundException, SQLException {
		DBConnection connections = new DBConnection();

		Connection connection = connections.createConnection();

		Statement stmt = null;
		try {
			stmt = connection.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// stmt.executeUpdate("DROP TABLE IF EXISTS users");
		// stmt.executeUpdate("CREATE TABLE users (email VARCHAR(25),password
		// VARCHAR(25))");
		/*
		 * CREATE TABLE table_name (column_name1 datatype, column_name2
		 * datatype, ... column_nameN datatype );
		 */
		// stmt.executeUpdate("INSERT INTO users(email,password) VALUES
		// ('verma9931@gmail.com','abhi007')");
		ResultSet rs = null;
		try {
			rs = stmt.executeQuery(
					// verma9931@gmail.com - abhi007  isactive='true' AND 
					"SELECT id, e_mail,user_name,password,name,role,totalLead,openLead,closeLead FROM users where user_name='"
							+ email + "' AND password='" + pass + "'");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			dto = new UserDTO();
			if (rs.next()) {
				dto.setId(rs.getInt("id") + "");
				dto.setE_mail(rs.getString("e_mail"));
				dto.setUser_name(rs.getString("user_name"));
				dto.setPassword(rs.getString("password"));
				dto.setName(rs.getString("name"));
				dto.setRole(rs.getString("role"));
				dto.setTotalLead(rs.getInt("totalLead"));
				dto.setOpenLead(rs.getInt("openLead"));
				dto.setCloseLead(rs.getInt("closeLead"));
				System.out.println("Read from DB ID: " + dto.getId());
				System.out.println("Read from DB Email: " + rs.getString("user_name"));
				// System.out.println("Read from DB Password: " +
				// rs.getString("password"));
				System.out.println("Read from DB name: " + rs.getString("name"));
				System.out.println("Read from DB role: " + rs.getString("role"));
				System.out.println("Read from DB role: " + rs.getInt("totalLead"));
				System.out.println("Read from DB role: " + rs.getInt("openLead"));
				System.out.println("Read from DB role: " + rs.getInt("closeLead"));
				//return dto;
			} else {
				dto = null;
				//return null;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		connection.close();
		return dto;
	}

	public static void main(String[] args) throws URISyntaxException, ClassNotFoundException, SQLException {
		LoginService loginService = new LoginService();
		// loginService.login("verma9931@gmail.com", "abhi007");//admin
		loginService.login("va00017@gmail.com", "abhi007");// EMP

	}
}
